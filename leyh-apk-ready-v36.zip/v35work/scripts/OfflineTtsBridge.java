package com.leyhqalha.leyh;

import android.app.Activity;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import com.k2fsa.sherpa.onnx.GeneratedAudio;
import com.k2fsa.sherpa.onnx.OfflineTts;
import com.k2fsa.sherpa.onnx.OfflineTtsConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OfflineTtsBridge {
    private final Activity activity;
    private final Context context;
    private final WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private OfflineTts tts;
    private MediaPlayer player;
    private int runId = 0;

    public OfflineTtsBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.webView = webView;
    }

    @JavascriptInterface
    public synchronized void speak(String text, float speed) {
        if (text == null || text.trim().isEmpty()) return;
        final int run = ++runId;
        stopPlayer();
        executor.execute(() -> {
            try {
                OfflineTts engine = getTts();
                float safeSpeed = Math.max(0.7f, Math.min(1.25f, speed));
                GeneratedAudio audio = engine.generate(text, 0, safeSpeed);
                if (run != runId) return;
                File out = new File(context.getCacheDir(), "leyh_kareem.wav");
                if (!audio.save(out.getAbsolutePath())) throw new Exception("تعذر إنشاء ملف الصوت");
                play(out, run);
            } catch (Throwable e) {
                if (run == runId) jsError(e.getMessage() == null ? "تعذر تشغيل الصوت" : e.getMessage());
            }
        });
    }

    @JavascriptInterface public synchronized void stop() { runId++; stopPlayer(); }
    @JavascriptInterface public void pause() { activity.runOnUiThread(() -> { if (player != null && player.isPlaying()) player.pause(); }); }
    @JavascriptInterface public void resume() { activity.runOnUiThread(() -> { if (player != null) player.start(); }); }
    @JavascriptInterface public boolean isPlaying() { return player != null && player.isPlaying(); }

    private synchronized OfflineTts getTts() throws Exception {
        if (tts != null) return tts;
        // Load Kareem directly from APK assets. Sherpa's AssetManager constructor
        // expects model paths relative to the APK assets directory.
        final String base = "tts-model/vits-piper-ar_JO-kareem-medium";
        OfflineTtsVitsModelConfig vits = new OfflineTtsVitsModelConfig();
        vits.setModel(base + "/ar_JO-kareem-medium.onnx");
        vits.setTokens(base + "/tokens.txt");
        vits.setDataDir(base + "/espeak-ng-data");
        OfflineTtsModelConfig model = new OfflineTtsModelConfig();
        model.setVits(vits); model.setNumThreads(2); model.setDebug(false);
        OfflineTtsConfig config = new OfflineTtsConfig();
        config.setModel(model); config.setMaxNumSentences(1);
        tts = new OfflineTts(context.getAssets(), config);
        return tts;
    }

    private void play(File file, int run) {
        activity.runOnUiThread(() -> {
            if (run != runId) return;
            stopPlayer();
            try {
                player = new MediaPlayer();
                player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                player.setDataSource(file.getAbsolutePath());
                player.setOnCompletionListener(mp -> { mp.release(); player = null; if (run == runId) jsDone(); });
                player.setOnErrorListener((mp, what, extra) -> { mp.release(); player = null; if (run == runId) jsError("تعذر تشغيل ملف الصوت"); return true; });
                player.prepare(); player.start();
            } catch (Exception e) {
                if (player != null) { player.release(); player = null; }
                jsError(e.getMessage() == null ? "تعذر تشغيل الصوت" : e.getMessage());
            }
        });
    }

    private synchronized void stopPlayer() {
        activity.runOnUiThread(() -> {
            if (player != null) {
                try { player.stop(); } catch (Exception ignored) { }
                try { player.release(); } catch (Exception ignored) { }
                player = null;
            }
        });
    }

    private void jsDone() { webView.post(() -> webView.evaluateJavascript("window.__leyhOfflineTtsDone&&window.__leyhOfflineTtsDone()", null)); }
    private void jsError(String message) { webView.post(() -> webView.evaluateJavascript("window.__leyhOfflineTtsError&&window.__leyhOfflineTtsError(" + quote(message) + ")", null)); }
    private String quote(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""; }

    public synchronized void shutdown() {
        runId++; stopPlayer();
        try { if (tts != null) tts.release(); } catch (Exception ignored) { }
        executor.shutdownNow();
    }
}
