import React, { useState, useEffect, useRef } from 'react';
import { audioEngine, SOLEMN_VOICE } from '../utils/audioService';
import { Play, Pause, Sparkles, Volume2 } from 'lucide-react';

interface HadithReciterPlayerProps {
  hadithText: string;
  narrator?: string;
  source?: string;
  variant?: 'card' | 'compact' | 'bar-only';
  showText?: boolean;
  onPlayStateChange?: (isPlaying: boolean) => void;
}

export const HadithReciterPlayer: React.FC<HadithReciterPlayerProps> = ({
  hadithText,
  narrator,
  source,
  variant = 'card',
  showText = true,
  onPlayStateChange
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [durationSec, setDurationSec] = useState(0);
  const progressBarRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (onPlayStateChange) {
      onPlayStateChange(isPlaying);
    }
  }, [isPlaying, onPlayStateChange]);

  const handleTogglePlay = () => {
    if (isPlaying) {
      audioEngine.stopSpeaking();
      setIsPlaying(false);
      setProgress(0);
      setCurrentTimeSec(0);
    } else {
      setIsPlaying(true);
      void (async () => {
        audioEngine.reciteHadith(hadithText, {
        pitch: SOLEMN_VOICE.pitch,
        speed: SOLEMN_VOICE.rate,
        onProgress: (pct, cur, total) => {
          setProgress(pct);
          setCurrentTimeSec(cur);
          setDurationSec(total);
        },
        onEnd: () => {
          setIsPlaying(false);
              setProgress(0);
          setCurrentTimeSec(0);
        },
        onError: () => {
          setIsPlaying(false);
            },
        language: 'ar',
      });
      })();
    }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const newPercent = ratio * 100;
    setProgress(newPercent);
    audioEngine.seekPercent(newPercent);
  };

  useEffect(() => {
    return () => {
      audioEngine.stopSpeaking();
    };
  }, []);

  const formatSecs = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Compact variant for compact lists
  if (variant === 'compact') {
    return (
      <div className="flex items-center gap-2">
        <button
          onClick={handleTogglePlay}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm active:scale-95 ${
            isPlaying
              ? 'bg-[#E2B773] text-[#0D131F] shadow-[#E2B773]/20 animate-pulse'
              : 'bg-[#1E293B] hover:bg-[#E2B773]/20 text-[#E2B773] border border-[#E2B773]/30'
          }`}
          title="استماع الحديث"
        >
          {isPlaying ? (
            <>
              <Pause className="w-3.5 h-3.5 fill-current" />
              <span>إيقاف</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
              <span>استماع الحديث</span>
            </>
          )}
        </button>

        {isPlaying && (
          <div className="flex items-center gap-0.5 h-3 px-1">
            <span className="w-1 bg-[#E2B773] rounded-full animate-bounce h-3" />
            <span className="w-1 bg-[#E2B773] rounded-full animate-bounce [animation-delay:0.15s] h-2" />
            <span className="w-1 bg-[#E2B773] rounded-full animate-bounce [animation-delay:0.3s] h-3.5" />
          </div>
        )}
      </div>
    );
  }

  // Bar only variant (no text on top)
  if (variant === 'bar-only' || !showText) {
    return (
      <div className="w-full rounded-2xl bg-[#0D131F] border border-[#E2B773]/30 p-3 shadow-lg relative overflow-hidden">
        {isPlaying && (
          <div className="absolute inset-0 bg-[#E2B773]/5 pointer-events-none transition-opacity duration-500 animate-pulse" />
        )}
        <div className="flex flex-col sm:flex-row items-center gap-3 relative z-10">
          <button
            onClick={handleTogglePlay}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 transition-all shrink-0 active:scale-95 shadow-md ${
              isPlaying
                ? 'bg-[#E2B773] text-[#0D131F] shadow-[#E2B773]/30 animate-pulse'
                : 'bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F]'
            }`}
            title={isPlaying ? 'إيقاف استماع الحديث' : 'استماع الحديث'}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>إيقاف</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>استماع الحديث</span>
              </>
            )}
          </button>

          <div className="flex-1 w-full">
            <div
              ref={progressBarRef}
              onClick={handleSeek}
              className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden relative cursor-pointer group"
            >
              <div
                className="h-full bg-gradient-to-r from-[#C99846] to-[#F3D59B] transition-all duration-150 rounded-full"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mt-1.5 px-0.5">
              <span className={isPlaying ? 'text-[#E2B773] font-bold' : ''}>
                {isPlaying ? 'جارٍ استماع الحديث...' : 'شريط استماع الحديث'}
              </span>
              <span>
                {formatSecs(currentTimeSec)} / {formatSecs(durationSec)}
              </span>
            </div>
          </div>

          <div className="flex items-end gap-1 h-6 px-1 shrink-0">
            {[40, 75, 100, 60, 90, 50].map((h, i) => (
              <div
                key={i}
                className={`w-1 rounded-full bg-[#E2B773] transition-all duration-300 ${
                  isPlaying ? 'animate-pulse' : 'opacity-30'
                }`}
                style={{
                  height: isPlaying ? `${h}%` : '20%',
                  animationDelay: `${i * 120}ms`
                }}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Default Full Card Variant: شريط صوتي وفوقه الحديث مكتوب
  return (
    <div className="hadith-reciter-card w-full rounded-3xl bg-[#0D131F] border border-[#E2B773]/40 shadow-2xl relative overflow-hidden transition-all duration-300 hover:border-[#E2B773]/60">
      {/* Glow when playing */}
      {isPlaying && (
        <div className="absolute inset-0 bg-[#E2B773]/5 pointer-events-none transition-opacity duration-500 animate-pulse" />
      )}

      {/* Top Header Label */}
      <div className="flex items-center justify-between px-5 pt-4 pb-2 relative z-10 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-[#E2B773]/15 border border-[#E2B773]/30 flex items-center justify-center text-[#E2B773]">
            <Volume2 className="w-4 h-4" />
          </div>
          <span className="text-xs font-bold text-[#E2B773] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>نص الحديث الشريف</span>
          </span>
        </div>

        {(narrator || source) && (
          <span className="text-[11px] text-slate-400 font-medium">
            {narrator ? `عن ${narrator}` : source}
          </span>
        )}
      </div>

      {/* 1. الحديث مكتوب في الأعلى */}
      <div className="px-5 py-5 text-center relative z-10">
        <p className="font-hadith text-lg sm:text-xl md:text-2xl font-bold text-amber-50 leading-loose select-text selection:bg-[#E2B773]/30">
          «{hadithText}»
        </p>
      </div>

      {/* 2. تحته مباشرة: شريط صوتي متكامل */}
      <div className="bg-[#12192A] border-t border-[#E2B773]/25 px-4 py-3 sm:px-5 sm:py-3.5 relative z-10">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* زر استماع الحديث */}
          <button
            onClick={handleTogglePlay}
            className={`w-full sm:w-auto px-5 py-2.5 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all shrink-0 active:scale-95 shadow-lg ${
              isPlaying
                ? 'bg-[#E2B773] text-[#0D131F] shadow-[#E2B773]/30 animate-pulse'
                : 'bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] shadow-[#E2B773]/20'
            }`}
            title={isPlaying ? 'إيقاف استماع الحديث' : 'استماع الحديث'}
          >
            {isPlaying ? (
              <>
                <Pause className="w-4 h-4 fill-current" />
                <span>إيقاف</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>استماع الحديث</span>
              </>
            )}
          </button>

          {/* مسار الشريط الصوتي والتقدم */}
          <div className="flex-1 w-full flex flex-col gap-1.5">
            <div
              ref={progressBarRef}
              onClick={handleSeek}
              className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden relative cursor-pointer group"
              title="انقر لتقديم أو تأخير الصوت"
            >
              <div
                className="h-full bg-gradient-to-r from-[#C99846] to-[#F3D59B] transition-all duration-150 rounded-full relative"
                style={{ width: `${progress}%` }}
              >
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 px-0.5">
              <span className={`text-[11px] ${isPlaying ? 'text-[#E2B773] font-bold' : 'text-slate-400'}`}>
                {isPlaying ? 'جارٍ استماع الحديث...' : 'شريط صوتي (وقور عميق)'}
              </span>
              <span className="tracking-wider">
                {formatSecs(currentTimeSec)} / {formatSecs(durationSec)}
              </span>
            </div>
          </div>

          {/* ذبذبات الأمواج الصوتية المتحركة */}
          <div className="hidden sm:flex items-end gap-1 h-6 px-1 shrink-0">
            {[45, 85, 100, 65, 95, 55].map((h, i) => (
              <div
                key={i}
                className={`w-1 rounded-full bg-[#E2B773] transition-all duration-300 ${
                  isPlaying ? 'animate-pulse' : 'opacity-30'
                }`}
                style={{
                  height: isPlaying ? `${h}%` : '20%',
                  animationDelay: `${i * 120}ms`
                }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
