import React, { useState, useEffect, useRef } from 'react';
import { HadithItem } from '../types/hadith';
import { audioEngine, SOLEMN_VOICE, cleanStoryContentForSpeech } from '../utils/audioService';
import { mosqueMinaretImage } from '../data/hadiths';
import { X, Play, Pause, Volume2, Sparkles, BookOpen } from 'lucide-react';

interface AudioPlayerModalProps {
  hadith: HadithItem;
  isOpen?: boolean;
  onClose: () => void;
}

export const AudioPlayerModal: React.FC<AudioPlayerModalProps> = ({ hadith, isOpen = true, onClose }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playMode, setPlayMode] = useState<'story' | 'hadith'>('story');
  const [progressPercent, setProgressPercent] = useState(0);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [durationSec, setDurationSec] = useState(0);
  const progressBarRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const storyText = cleanStoryContentForSpeech(
    hadith.scenes?.length ? hadith.scenes.map(s => s.content).join(' ') : hadith.context || hadith.hadith_text
  );
  const directHadithText = cleanStoryContentForSpeech(hadith.hadith_text);
  const currentTextToPlay = playMode === 'story' ? storyText : directHadithText;

  const handleTogglePlay = () => {
    if (isPlaying) {
      audioEngine.stopSpeaking();
      setIsPlaying(false);
      setProgressPercent(0);
      setCurrentTimeSec(0);
      return;
    }

    setIsPlaying(true);
    audioEngine.reciteHadith(currentTextToPlay, {
      pitch: SOLEMN_VOICE.pitch,
      speed: SOLEMN_VOICE.rate,
      language: 'ar',
      onProgress: (progress, current, duration) => {
        setProgressPercent(progress);
        setCurrentTimeSec(current);
        setDurationSec(duration);
      },
      onEnd: () => {
        setIsPlaying(false);
        setProgressPercent(0);
        setCurrentTimeSec(0);
      },
      onError: () => setIsPlaying(false),
    });
  };

  const handleSeekClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const newPercent = ratio * 100;
    setProgressPercent(newPercent);
    audioEngine.seekPercent(newPercent);
  };

  const handleSwitchMode = (newMode: 'story' | 'hadith') => {
    if (playMode === newMode) return;
    audioEngine.stopSpeaking();
    setIsPlaying(false);
    setProgressPercent(0);
    setCurrentTimeSec(0);
    setPlayMode(newMode);
  };

  useEffect(() => () => audioEngine.stopSpeaking(), []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]"><Volume2 className="w-4 h-4" /></div>
            <div>
              <span className="text-xs font-bold text-slate-200 block">مشغل الاستماع الوقور</span>
              <span className="text-[10px] text-[#E2B773] font-medium">صوت وقور عميق</span>
            </div>
          </div>
          <button onClick={() => { audioEngine.stopSpeaking(); onClose(); }} className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-5 flex flex-col items-center">
          <div className="relative w-44 h-44 rounded-2xl overflow-hidden mb-3 border border-slate-700 shadow-xl">
            <img src={mosqueMinaretImage} alt={hadith.topic} className={`w-full h-full object-cover transition-transform duration-700 ${isPlaying ? 'scale-110 brightness-90' : 'scale-100 brightness-75'}`} />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D131F] via-transparent to-transparent opacity-80" />
            {isPlaying && <div className="absolute inset-0 flex items-center justify-center"><div className="w-20 h-20 rounded-full border-2 border-[#E2B773]/60 animate-ping opacity-60" /><div className="w-28 h-28 rounded-full border border-[#E2B773]/30 animate-pulse opacity-40" /></div>}
            <div className="absolute bottom-2.5 right-2.5 left-2.5 text-center">
              <span className="text-[10px] font-mono tracking-wider text-[#E2B773] block">{hadith.hadith_number ? `حديث رقم ${hadith.hadith_number}` : 'الحديث النبوي'}</span>
              <span className="text-xs font-bold text-white line-clamp-1">{hadith.topic}</span>
            </div>
          </div>

          <div className="flex bg-[#0D131F] p-1 rounded-xl border border-slate-800 w-full mb-3">
            <button onClick={() => handleSwitchMode('story')} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${playMode === 'story' ? 'bg-[#E2B773] text-[#0D131F] shadow-sm' : 'text-slate-400 hover:text-white'}`}>الاستماع للقصة</button>
            <button onClick={() => handleSwitchMode('hadith')} className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${playMode === 'hadith' ? 'bg-[#E2B773] text-[#0D131F] shadow-sm' : 'text-slate-400 hover:text-white'}`}>استماع الحديث</button>
          </div>

          {playMode === 'hadith' && <div className="w-full bg-[#0D131F] p-4 rounded-2xl border border-[#E2B773]/30 mb-3 text-center"><span className="text-[10px] text-[#E2B773] font-bold block mb-1.5"><Sparkles className="w-3 h-3 inline ml-1" />نص الحديث الشريف</span><p className="font-hadith text-base sm:text-lg font-bold text-amber-100 leading-loose max-h-36 overflow-y-auto px-1">«{directHadithText}»</p></div>}

          <div className="w-full mt-1 bg-[#0D131F] p-3 rounded-2xl border border-slate-800/80">
            <div ref={progressBarRef} onClick={handleSeekClick} className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden cursor-pointer relative"><div className="bg-gradient-to-r from-[#C99846] to-[#F3D59B] h-full transition-all duration-150" style={{ width: `${progressPercent}%` }} /></div>
            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-2 px-1"><span className="text-[#E2B773] font-sans font-bold">{isPlaying ? (playMode === 'story' ? 'استماع القصة جارٍ...' : 'استماع الحديث جارٍ...') : 'وقور عميق'}</span><span>{Math.floor(currentTimeSec / 60)}:{Math.floor(currentTimeSec % 60).toString().padStart(2, '0')} / {Math.floor(durationSec / 60)}:{Math.floor(durationSec % 60).toString().padStart(2, '0')}</span></div>
          </div>

          <button onClick={handleTogglePlay} className="mt-4 px-8 py-3.5 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] active:scale-95 text-[#0D131F] font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#E2B773]/30 transition-all">
            {isPlaying ? <><Pause className="w-5 h-5 fill-current" /><span>إيقاف</span></> : <><Play className="w-5 h-5 fill-current" /><span>{playMode === 'story' ? 'الاستماع للقصة' : 'استماع الحديث'}</span></>}
          </button>

          <div className="mt-4 pt-3 border-t border-slate-800/80 w-full text-center"><span className="text-[10px] text-slate-400 flex items-center justify-center gap-1.5"><BookOpen className="w-3.5 h-3.5 text-[#E2B773]" />نبرة صوت واحدة رصينة بدون مؤثرات صوتية إضافية</span></div>
        </div>
      </div>
    </div>
  );
};
