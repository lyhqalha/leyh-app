import React, { useState, useMemo } from 'react';
import { HadithItem } from '../types/hadith';
import { Search, X, History, Sparkles, BookOpen } from 'lucide-react';

interface SearchViewProps {
  hadiths: HadithItem[];
  onSelectHadith: (hadith: HadithItem) => void;
  onOpenStory: (hadith: HadithItem) => void;
}

type SearchScope = 'all' | 'hadith' | 'narrator' | 'topic' | 'keywords';

export const SearchView: React.FC<SearchViewProps> = ({ hadiths, onSelectHadith, onOpenStory }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchScope, setSearchScope] = useState<SearchScope>('all');
  const [searchVisibleCount, setSearchVisibleCount] = useState<number>(30);
  const [recentSearches, setRecentSearches] = useState<string[]>([
    'الصبر',
    'أبو هريرة',
    'صحيح البخاري',
    'النية',
    'الرحمة',
    'الأدب'
  ]);

  const filteredResults = useMemo(() => {
    const term = searchTerm.trim().toLowerCase();
    if (!term) return [];

    return hadiths.filter(item => {
      if (searchScope === 'all') {
        return (
          item.hadith_text.toLowerCase().includes(term) ||
          item.narrator.toLowerCase().includes(term) ||
          item.topic.toLowerCase().includes(term) ||
          item.source.toLowerCase().includes(term) ||
          item.keywords.some(k => k.toLowerCase().includes(term))
        );
      }
      if (searchScope === 'hadith') {
        return item.hadith_text.toLowerCase().includes(term);
      }
      if (searchScope === 'narrator') {
        return item.narrator.toLowerCase().includes(term);
      }
      if (searchScope === 'topic') {
        return item.topic.toLowerCase().includes(term);
      }
      if (searchScope === 'keywords') {
        return item.keywords.some(k => k.toLowerCase().includes(term));
      }
      return false;
    });
  }, [searchTerm, searchScope, hadiths]);

  const handleApplyRecent = (term: string) => {
    setSearchTerm(term);
  };

  const handleClear = () => {
    setSearchTerm('');
  };

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto">
      {/* Title */}
      <h2 className="text-xl font-bold text-center text-white mb-4">البحث المتقدم</h2>

      {/* Search Input Box */}
      <div className="relative mb-3">
        <div className="absolute right-3.5 top-3.5 text-slate-400">
          <Search className="w-5 h-5" />
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="ابحث في نص الحديث أو الراوي أو الموضوع..."
          className="w-full h-12 pr-11 pl-10 rounded-2xl bg-[#131B2E] border border-slate-700/80 text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-[#E2B773] focus:ring-1 focus:ring-[#E2B773] transition-all"
        />
        {searchTerm && (
          <button
            onClick={handleClear}
            className="absolute left-3.5 top-3.5 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Filter Tabs / Scopes */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none mb-4">
        {[
          { id: 'all', label: 'الكل' },
          { id: 'hadith', label: 'الحديث' },
          { id: 'narrator', label: 'الراوي' },
          { id: 'topic', label: 'الموضوع' },
          { id: 'keywords', label: 'الكلمات المفتاحية' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setSearchScope(tab.id as SearchScope)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              searchScope === tab.id
                ? 'bg-[#E2B773] text-[#0D131F] shadow'
                : 'bg-[#131B2E] text-slate-400 hover:text-slate-200 border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* If No Query: Recent Searches Section */}
      {!searchTerm && (
        <div className="mt-6">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3 px-1">
            <span className="font-semibold flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-[#E2B773]" />
              <span>عمليات البحث الأخيرة</span>
            </span>
          </div>

          <div className="space-y-2">
            {recentSearches.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleApplyRecent(item)}
                className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#131B2E] border border-slate-800/80 hover:border-slate-700 text-right text-xs text-slate-300 hover:text-white transition-all group"
              >
                <span className="font-medium">{item}</span>
                <Search className="w-3.5 h-3.5 text-slate-500 group-hover:text-[#E2B773]" />
              </button>
            ))}
          </div>

          {/* Quick Suggestions / Topics */}
          <div className="mt-8">
            <span className="text-xs font-semibold text-slate-400 block mb-3 px-1">
              موضوعات مقترحة للبحث
            </span>
            <div className="flex flex-wrap gap-2">
              {['حسن الخلق', 'اللسان', 'الرحمة', 'الجار والضيف', 'مهاجر أم قيس', 'بر الوالدين', 'التوبة'].map((t) => (
                <button
                  key={t}
                  onClick={() => handleApplyRecent(t)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800/70 hover:bg-slate-700 text-xs text-slate-300 hover:text-white border border-slate-700/60"
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Search Results */}
      {searchTerm && (
        <div>
          <div className="flex items-center justify-between text-xs text-slate-400 mb-3 px-1">
            <span>النتائج ({filteredResults.length})</span>
            <span>البحث عن: «{searchTerm}»</span>
          </div>

          {filteredResults.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-[#131B2E] border border-slate-800">
              <p className="text-sm text-slate-400 mb-2">لم يتم العثور على نتائج تطابق بحثك</p>
              <p className="text-xs text-slate-500">جرب البحث بكلمات أخرى أو تغيير تصنيف البحث أعلاه</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredResults.slice(0, searchVisibleCount).map((item) => (
                <div
                  key={item.id}
                  className="rounded-2xl p-4 bg-[#131B2E] border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col gap-2.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded-md bg-[#E2B773]/15 text-[#E2B773] font-bold">
                      {item.topic}
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {item.source} · {item.hadith_number}
                    </span>
                  </div>

                  <p className="font-hadith text-base text-slate-100 font-bold leading-relaxed line-clamp-2">
                    {item.hadith_text}
                  </p>

                  <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800/60">
                    <span>الراوي: {item.narrator}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenStory(item)}
                        className="text-xs font-semibold text-[#E2B773] hover:underline flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>الاستماع للقصة</span>
                      </button>
                      <button
                        onClick={() => onSelectHadith(item)}
                        className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>التفاصيل</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {searchVisibleCount < filteredResults.length && (
                <div className="pt-2 flex justify-center">
                  <button
                    onClick={() => setSearchVisibleCount(prev => prev + 30)}
                    className="w-full py-3 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-[#E2B773]/40 text-xs font-bold text-[#E2B773] transition-all flex items-center justify-center gap-2 active:scale-95 shadow-md"
                  >
                    <span>عرض المزيد من نتائج البحث ({searchVisibleCount} من أصل {filteredResults.length})</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
