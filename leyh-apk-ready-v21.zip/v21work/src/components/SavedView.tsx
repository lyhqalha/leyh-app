import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { Star, Bookmark, Sparkles, BookOpen } from 'lucide-react';

interface SavedViewProps {
  hadiths: HadithItem[];
  bookmarkedIds: string[];
  onToggleBookmark: (id: string) => void;
  onSelectHadith: (hadith: HadithItem) => void;
  onOpenStory: (hadith: HadithItem) => void;
}

export const SavedView: React.FC<SavedViewProps> = ({
  hadiths,
  bookmarkedIds,
  onToggleBookmark,
  onSelectHadith,
  onOpenStory,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'favorites'>('all');

  const savedHadiths = hadiths.filter(h => bookmarkedIds.includes(h.id));

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto">
      <h2 className="text-xl font-bold text-center text-white mb-4">المحفوظات</h2>

      {/* Tabs: الكل / المفضلة */}
      <div className="flex bg-[#131B2E] p-1 rounded-2xl mb-5 border border-slate-800">
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'all'
              ? 'bg-[#E2B773] text-[#0D131F] shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          الكل ({savedHadiths.length})
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'favorites'
              ? 'bg-[#E2B773] text-[#0D131F] shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          المفضلة ({savedHadiths.length})
        </button>
      </div>

      {savedHadiths.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-[#131B2E] border border-slate-800">
          <Bookmark className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h4 className="text-base font-bold text-slate-200 mb-1">لا توجد أحاديث محفوظة حالياً</h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            اضغط على علامة الحفظ في أي حديث لتتمكن من الرجوع إليه وقراءته أو الاستماع إليه لاحقاً.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {savedHadiths.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 transition-all flex flex-col gap-2 relative group"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onToggleBookmark(item.id)}
                    className="text-[#E2B773] hover:text-amber-300"
                    title="إزالة الحفظ"
                  >
                    <Star className="w-4 h-4 fill-current" />
                  </button>
                  <span className="text-[11px] text-slate-400">
                    {item.source} | {item.hadith_number}
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded-lg bg-slate-800 text-[11px] text-[#E2B773] font-semibold">
                  {item.topic}
                </span>
              </div>

              <p className="font-hadith text-base font-bold text-slate-100 leading-relaxed line-clamp-2 mt-1">
                {item.hadith_text}
              </p>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                <span className="text-slate-400">الراوي: {item.narrator}</span>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onOpenStory(item)}
                    className="text-xs font-semibold text-[#E2B773] hover:underline flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>الاستماع للقصة</span>
                  </button>
                  <button
                    onClick={() => onSelectHadith(item)}
                    className="text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>التفاصيل</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
