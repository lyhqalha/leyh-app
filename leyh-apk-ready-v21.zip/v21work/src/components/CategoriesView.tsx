import React, { useState } from 'react';
import { CATEGORIES_LIST } from '../data/hadiths';
import { HadithItem } from '../types/hadith';
import {
  ShieldCheck,
  MessageSquareHeart,
  Smile,
  Sparkles,
  UsersRound,
  Users,
  Compass,
  Moon,
  Flame,
  RotateCcw,
  BookOpen,
  Heart,
  Award,
  GraduationCap,
  Coins,
  Navigation,
  ArrowRight,
  HandHeart
} from 'lucide-react';

interface CategoriesViewProps {
  hadiths: HadithItem[];
  onSelectCategoryHadith: (hadith: HadithItem) => void;
  onOpenStory: (hadith: HadithItem) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  hadiths,
  onSelectCategoryHadith,
  onOpenStory
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryVisibleCount, setCategoryVisibleCount] = useState<number>(30);

  // Icon mapping
  const renderIcon = (name: string) => {
    const props = { className: 'w-5 h-5 text-[#E2B773]' };
    switch (name) {
      case 'ShieldCheck': return <ShieldCheck {...props} />;
      case 'MessageSquareHeart': return <MessageSquareHeart {...props} />;
      case 'Smile': return <Smile {...props} />;
      case 'Sparkles': return <Sparkles {...props} />;
      case 'UsersRound': return <UsersRound {...props} />;
      case 'Users': return <Users {...props} />;
      case 'Compass': return <Compass {...props} />;
      case 'Moon': return <Moon {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'RotateCcw': return <RotateCcw {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'Heart': return <Heart {...props} />;
      case 'Award': return <Award {...props} />;
      case 'GraduationCap': return <GraduationCap {...props} />;
      case 'Coins': return <Coins {...props} />;
      case 'Navigation': return <Navigation {...props} />;
      default: return <HandHeart {...props} />;
    }
  };

  const selectedCategoryObj = CATEGORIES_LIST.find(c => c.name === selectedCategory);
  const matchingHadiths = selectedCategory
    ? hadiths.filter(
        h =>
          h.topic === selectedCategory ||
          h.topic.includes(selectedCategory) ||
          selectedCategory.includes(h.topic) ||
          h.keywords.some(k => k.includes(selectedCategory) || selectedCategory.includes(k))
      )
    : [];

  const paginatedCategoryHadiths = matchingHadiths.slice(0, categoryVisibleCount);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto">
      {/* If a category is selected, show its Hadiths list */}
      {selectedCategory ? (
        <div className="space-y-4 animate-fadeIn">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <button
              onClick={() => {
                setSelectedCategory(null);
                setCategoryVisibleCount(30);
              }}
              className="inline-flex items-center gap-2 text-xs font-bold text-slate-300 hover:text-white"
            >
              <ArrowRight className="w-4 h-4" />
              <span>العودة للتصنيفات</span>
            </button>
            <span className="text-sm font-bold text-[#E2B773]">
              {selectedCategory} ({matchingHadiths.length} حديث)
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#131B2E] border border-slate-800 text-xs text-slate-400">
            {selectedCategoryObj?.description || 'مجموعة من الأحاديث النبوية الشريفة المتعلقة بهذا الباب'}
          </div>

          {matchingHadiths.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-[#131B2E] border border-slate-800">
              <p className="text-sm text-slate-400">يجري تصنيف وإضافة المزيد من أحاديث هذا الباب في موسوعة الـ 2000 حديث صحيح</p>
            </div>
          ) : (
            <div className="space-y-3">
              {paginatedCategoryHadiths.map((h) => (
                <div
                  key={h.id}
                  className="rounded-2xl p-4 bg-[#131B2E] border border-slate-800 hover:border-slate-700 transition-all flex flex-col gap-2.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#E2B773] font-semibold">{h.source} · {h.hadith_number}</span>
                    <span className="text-emerald-400 font-medium">{h.authenticity_grade}</span>
                  </div>

                  <p className="font-hadith text-base font-bold text-slate-100 leading-relaxed">
                    {h.hadith_text}
                  </p>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs text-slate-400">
                    <span>{h.narrator}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenStory(h)}
                        className="text-xs font-semibold text-[#E2B773] hover:underline flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>الاستماع للقصة</span>
                      </button>
                      <button
                        onClick={() => onSelectCategoryHadith(h)}
                        className="text-xs font-semibold text-slate-300 hover:text-white"
                      >
                        التفاصيل
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {categoryVisibleCount < matchingHadiths.length && (
                <div className="pt-2 flex justify-center">
                  <button
                    onClick={() => setCategoryVisibleCount(prev => prev + 30)}
                    className="w-full py-3 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-[#E2B773]/40 text-xs font-bold text-[#E2B773] transition-all flex items-center justify-center gap-2 active:scale-95 shadow-md"
                  >
                    <span>عرض المزيد من أحاديث الباب ({categoryVisibleCount} من أصل {matchingHadiths.length})</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div>
          {/* Main Categories Grid */}
          <h2 className="text-xl font-bold text-center text-white mb-1">التصنيفات الموضوعية</h2>
          <p className="text-xs text-center text-slate-400 mb-5">
            تصفح الأحاديث النبوية بحسب أبواب الشريعة ومناحي الحياة
          </p>

          <div className="grid grid-cols-3 sm:grid-cols-3 gap-3">
            {CATEGORIES_LIST.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.name)}
                className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-[#E2B773]/50 hover:bg-[#1a233a] active:scale-95 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#1E293B] group-hover:bg-[#E2B773]/15 flex items-center justify-center mb-2.5 transition-colors">
                  {renderIcon(category.iconName)}
                </div>
                <span className="text-xs font-bold text-slate-200 group-hover:text-white mb-1">
                  {category.name}
                </span>
                <span className="text-[10px] text-slate-400">
                  {category.count} حديث
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
