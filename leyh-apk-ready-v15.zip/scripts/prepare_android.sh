#!/usr/bin/env bash
set -euo pipefail

# Android 10+ only.
if [ -f android/variables.gradle ]; then
  sed -E -i 's/minSdkVersion = [0-9]+/minSdkVersion = 29/' android/variables.gradle
fi

if [ -f android/app/build.gradle ]; then
  if grep -Eq 'minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+' android/app/build.gradle; then
    sed -E -i 's/minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+/minSdk\1 = 29/g' android/app/build.gradle
  elif grep -q 'defaultConfig {' android/app/build.gradle; then
    sed -i '/defaultConfig {/a\        minSdk 29' android/app/build.gradle
  fi
fi

# Bundle notification audio in Android's raw resources.
mkdir -p android/app/src/main/res/raw
cp resources/salawat.wav android/app/src/main/res/raw/salawat.wav
cp resources/notification.wav android/app/src/main/res/raw/notification.wav

# Keep normal Android system bars visible (clock, network, battery, navigation bar).
# The app uses the available screen area without a fake phone frame.
MAIN_JAVA_DIR="android/app/src/main/java/com/leyhqalha/leyh"
mkdir -p "$MAIN_JAVA_DIR"
find android/app/src/main/java -type f \( -name 'MainActivity.java' -o -name 'MainActivity.kt' \) -delete
cat > "$MAIN_JAVA_DIR/MainActivity.java" <<'JAVA'
package com.leyhqalha.leyh;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private static final String DAILY_CHANNEL_ID = "daily-reading-v4";
    private static final String SALAWAT_CHANNEL_ID = "salawat-reminder-v4";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        createNotificationChannels();
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager =
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        // Use the explicit /raw/<name> form. This is valid for android.resource URIs
        // and avoids ambiguity with resource IDs on OEM Android builds.
        Uri dailySound = Uri.parse("android.resource://" + getPackageName() + "/raw/notification");
        Uri salawatSound = Uri.parse("android.resource://" + getPackageName() + "/raw/salawat");

        createChannelIfMissing(manager, DAILY_CHANNEL_ID,
            "تذكير القراءة اليومية", "تنبيهات يومية لقراءة حديث اليوم وقصته", dailySound, attrs);
        createChannelIfMissing(manager, SALAWAT_CHANNEL_ID,
            "الصلاة على النبي ﷺ", "تذكير صوتي للصلاة على النبي محمد ﷺ", salawatSound, attrs);
    }

    private void createChannelIfMissing(NotificationManager manager, String id, String name,
                                       String description, Uri sound, AudioAttributes attrs) {
        if (manager.getNotificationChannel(id) != null) return;

        NotificationChannel channel = new NotificationChannel(
            id, name, NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(description);
        channel.enableVibration(true);
        channel.setShowBadge(true);
        channel.setSound(sound, attrs);
        manager.createNotificationChannel(channel);
    }
}
JAVA
