v37: Kareem Sherpa TTS runs in a separate Android process to prevent native TTS crashes from closing the main app.
