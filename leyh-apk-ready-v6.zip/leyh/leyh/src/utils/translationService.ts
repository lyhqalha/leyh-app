export type ContentLanguage = 'ar' | 'en';

const cache = new Map<string, string>();

export async function translateArabicToEnglish(text: string): Promise<string> {
  const source = text?.trim();
  if (!source) return '';
  const cached = cache.get(source);
  if (cached) return cached;

  try {
    const chunks: string[] = [];
    for (let i = 0; i < source.length; i += 1800) chunks.push(source.slice(i, i + 1800));

    const translatedParts: string[] = [];
    for (const chunk of chunks) {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=en&dt=t&q=${encodeURIComponent(chunk)}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error('translation failed');
      const data = await response.json();
      const translated = Array.isArray(data?.[0])
        ? data[0].map((part: any) => part?.[0] || '').join('')
        : '';
      translatedParts.push(translated || chunk);
    }

    const result = translatedParts.join('');
    cache.set(source, result);
    return result;
  } catch {
    return source;
  }
}
