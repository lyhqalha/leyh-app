export type AppLanguage = 'ar' | 'en';

const LANGUAGE_KEY = 'leyh_app_language';

export function getSavedLanguage(): AppLanguage {
  try {
    return localStorage.getItem(LANGUAGE_KEY) === 'en' ? 'en' : 'ar';
  } catch {
    return 'ar';
  }
}

export function setSavedLanguage(language: AppLanguage) {
  try {
    localStorage.setItem(LANGUAGE_KEY, language);
  } catch {}
}

export function applyLanguageDirection(language: AppLanguage) {
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'en' ? 'ltr' : 'rtl';
  document.body.dir = language === 'en' ? 'ltr' : 'rtl';
}

export function enableGoogleEnglishTranslation() {
  setSavedLanguage('en');
  document.cookie = 'googtrans=/ar/en;path=/';
  window.location.reload();
}

export function disableGoogleEnglishTranslation() {
  setSavedLanguage('ar');
  document.cookie = 'googtrans=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
  window.location.reload();
}
