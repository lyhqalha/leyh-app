import React, { useEffect } from 'react';
import { AppLanguage, applyLanguageDirection } from '../utils/languageService';

interface GoogleTranslateProps {
  language: AppLanguage;
}

declare global {
  interface Window {
    googleTranslateElementInit?: () => void;
    google?: any;
  }
}

export const GoogleTranslate: React.FC<GoogleTranslateProps> = ({ language }) => {
  useEffect(() => {
    applyLanguageDirection(language);

    if (language !== 'en') return;

    const existing = document.getElementById('google-translate-script');
    if (existing) return;

    window.googleTranslateElementInit = () => {
      try {
        if (window.google?.translate?.TranslateElement) {
          new window.google.translate.TranslateElement(
            {
              pageLanguage: 'ar',
              includedLanguages: 'en',
              autoDisplay: false,
              multilanguagePage: true,
            },
            'google_translate_element'
          );
        }
      } catch {}
    };

    const script = document.createElement('script');
    script.id = 'google-translate-script';
    script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
    script.async = true;
    document.head.appendChild(script);
  }, [language]);

  return <div id="google_translate_element" className="google-translate-hidden" aria-hidden="true" />;
};
