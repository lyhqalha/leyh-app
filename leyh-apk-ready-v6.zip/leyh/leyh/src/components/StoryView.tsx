import React, { useState, useEffect } from 'react';
import { HadithItem, StoryScene } from '../types/hadith';
import { audioEngine, cleanStoryContentForSpeech } from '../utils/audioService';
import { ambientEngine, detectAmbientContext, AMBIENT_PRESETS } from '../utils/ambientSoundService';
import {
  desertHeroImage,
  companionsStoryImage,
  mosqueMinaretImage,
  prophetCourtyardImage,
  nightDesertStarsImage
} from '../data/hadiths';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { getSavedLanguage } from '../utils/languageService';
import { translateArabicToEnglish } from '../utils/translationService';
import { ArrowRight, ArrowLeft, Volume2, Square, Sparkles, BookOpen, Waves } from 'lucide-react';

interface StoryViewProps {
  hadith: HadithItem;
  onBack: () => void;
  onOpenHadithDetail: () => void;
  fontSize?: 'sm' | 'md' | 'lg';
}

export const StoryView: React.FC<StoryViewProps> = ({ hadith, onBack, onOpenHadithDetail, fontSize = 'md' }) => {
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const scene: StoryScene = hadith.scenes[currentSceneIndex] || hadith.scenes[0];
  const totalScenes = hadith.scenes.length;
  const ambientType = detectAmbientContext(hadith);
  const ambientPreset = AMBIENT_PRESETS[ambientType] || AMBIENT_PRESETS.sanctuary;

  const storyFontClasses = {
    sm: { title: 'text-2xl sm:text-3xl', body: 'text-sm sm:text-base', subtitle: 'text-xs sm:text-sm', reflection: 'text-xs sm:text-sm' },
    md: { title: 'text-3xl sm:text-4xl', body: 'text-base sm:text-lg', subtitle: 'text-sm sm:text-base', reflection: 'text-sm sm:text-base' },
    lg: { title: 'text-4xl sm:text-5xl', body: 'text-lg sm:text-xl', subtitle: 'text-base sm:text-lg', reflection: 'text-base sm:text-lg' },
  }[fontSize];

  // Background artwork based on scene progression and context
  const getSceneBackground = (index: number) => {
    const isNightOrQuiet = hadith.topic === 'الصلاة' || hadith.topic === 'الدعاء' || hadith.topic === 'رمضان';
    if (index === 0) return isNightOrQuiet ? nightDesertStarsImage : desertHeroImage;
    if (index === 1) return companionsStoryImage;
    if (index === 2) return prophetCourtyardImage;
    if (index === 3) return mosqueMinaretImage;
    return prophetCourtyardImage;
  };

  const currentBg = getSceneBackground(currentSceneIndex);

  const handleNext = () => {
    audioEngine.stopSpeaking();
    ambientEngine.stop();
    setIsPlayingAudio(false);
    if (currentSceneIndex < totalScenes - 1) {
      setCurrentSceneIndex(prev => prev + 1);
    } else {
      // Completed 5 scenes! Navigate to full detail page
      onOpenHadithDetail();
    }
  };

  const handlePrev = () => {
    audioEngine.stopSpeaking();
    ambientEngine.stop();
    setIsPlayingAudio(false);
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex(prev => prev - 1);
    }
  };

  const handleToggleAudio = () => {
    if (isPlayingAudio) {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
      setIsPlayingAudio(false);
    } else {
      setIsPlayingAudio(true);
      // Play contextual ambient sound layer
      ambientEngine.play(ambientType);

      // Read pure story content directly without any badges or titles
      const pureStory = cleanStoryContentForSpeech(scene.content || scene.audioText || '');
      const hadithExcerpt = scene.hadithTextExcerpt
        ? ` قال رسول الله صلى الله عليه وسلم: ${scene.hadithTextExcerpt}`
        : '';
      const textToSpeak = `${pureStory} ${hadithExcerpt}`.trim();
      const language = getSavedLanguage();
      void (async () => {
        const spokenText = language === 'en' ? await translateArabicToEnglish(textToSpeak) : textToSpeak;
        audioEngine.reciteHadith(spokenText, {
        onEnd: () => {
          setIsPlayingAudio(false);
          ambientEngine.stop();
        },
        onError: () => {
          setIsPlayingAudio(false);
          ambientEngine.stop();
        },
          language,
        });
      })();
    }
  };

  useEffect(() => {
    return () => {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
    };
  }, [currentSceneIndex]);

  return (
    <div className="relative w-full h-full min-h-[620px] flex flex-col justify-between overflow-hidden bg-[#0D131F] text-slate-100 select-none">
      {/* Background with cinematic overlay */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <img
          src={currentBg}
          alt="خلفية قصة الحديث"
          className="w-full h-full object-cover object-center filter brightness-[0.45] transition-all duration-1000 ease-out transform scale-105"
          referrerPolicy="no-referrer"
        />
        {/* Soft vignette & gradient scrim */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0D131F]/90 via-[#0D131F]/40 to-[#0D131F]/95 pointer-events-none" />
      </div>

      {/* Top Header Bar */}
      <header className="relative z-10 flex items-center justify-between px-5 pt-5 pb-3">
        <button
          onClick={() => {
            audioEngine.stopSpeaking();
            onBack();
          }}
          className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md border border-white/10 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-transform"
          title="رجوع"
        >
          <ArrowRight className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center">
          <span className="text-xs text-[#E2B773] font-medium tracking-wide">قصة الحديث</span>
          <span className="text-sm font-bold text-slate-200">{hadith.topic}</span>
        </div>

        {/* Scene progress badge (e.g. 1/5) */}
        <div className="px-3 py-1 rounded-full bg-slate-900/60 backdrop-blur-md border border-[#E2B773]/30 text-xs font-mono font-bold text-[#E2B773] shadow-[0_0_12px_rgba(226,183,115,0.15)]">
          {scene.sceneNumber} / {totalScenes}
        </div>
      </header>

      {/* Progress Line Bar across top */}
      <div className="relative z-10 px-5 flex gap-1.5 py-1">
        {hadith.scenes.map((_, idx) => (
          <div
            key={idx}
            onClick={() => {
              audioEngine.stopSpeaking();
              setIsPlayingAudio(false);
              setCurrentSceneIndex(idx);
            }}
            className={`h-1 flex-1 rounded-full cursor-pointer transition-all duration-500 ${
              idx === currentSceneIndex
                ? 'bg-[#E2B773] shadow-[0_0_8px_rgba(226,183,115,0.8)]'
                : idx < currentSceneIndex
                ? 'bg-[#E2B773]/50'
                : 'bg-white/20 hover:bg-white/40'
            }`}
          />
        ))}
      </div>

      {/* Center Story Content Card */}
      <main className="relative z-10 flex-1 flex flex-col justify-center px-6 py-4 max-w-lg mx-auto w-full">
        <div
          key={currentSceneIndex}
          className="bg-[#131B2E]/90 backdrop-blur-md border border-[#E2B773]/30 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center animate-scene-card animate-card-glow relative overflow-hidden"
        >
          {/* Subtle Corner Star Accent */}
          <div className="absolute top-3 right-3 text-[#E2B773]/30 text-xs font-serif pointer-events-none select-none">✤</div>
          <div className="absolute top-3 left-3 text-[#E2B773]/30 text-xs font-serif pointer-events-none select-none">✤</div>

          {/* Floating Badge */}
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#E2B773]/15 border border-[#E2B773]/35 text-[#E2B773] text-xs font-bold mb-4 animate-badge-float shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#E2B773]" />
            <span>{scene.badge}</span>
          </div>

          {/* Title with subtle shimmer */}
          <h2 className={`${storyFontClasses.title} font-extrabold text-white mb-2 leading-tight`}>
            {scene.title}
          </h2>

          {scene.subtitle && (
            <p className={`${storyFontClasses.subtitle} text-slate-400 mb-5 font-medium`}>
              {scene.subtitle}
            </p>
          )}

          {/* Hadith Excerpt Spotlight (For Scene 3 / Reveal) */}
          {scene.hadithTextExcerpt && (
            <div className="w-full my-4">
              <HadithReciterPlayer
                hadithText={scene.hadithTextExcerpt}
                variant="card"
                showText={true}
              />
            </div>
          )}

          {/* Main Story Narrative */}
          <p className={`${storyFontClasses.body} text-slate-300 leading-relaxed my-2 max-w-md`}>
            {scene.content}
          </p>

          {/* Reflection Prompt / Question (if Scene 2) */}
          {scene.reflectionPrompt && (
            <div className={`mt-4 p-3.5 rounded-xl bg-amber-950/30 border border-amber-700/40 ${storyFontClasses.reflection} text-amber-200/95 font-medium animate-soft-pulse shadow-sm`}>
              💡 {scene.reflectionPrompt}
            </div>
          )}

          {/* Voice Narration Button: الاستماع للقصة */}
          <div className="mt-6 flex flex-col items-center gap-2">
            <button
              onClick={handleToggleAudio}
              className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-full border text-xs sm:text-sm font-bold transition-all active:scale-95 ${
                isPlayingAudio
                  ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] shadow-lg shadow-[#E2B773]/30 animate-pulse'
                  : 'bg-slate-800/80 hover:bg-slate-700/90 border-[#E2B773]/40 text-[#E2B773] hover:text-white shadow-sm'
              }`}
            >
              {isPlayingAudio ? (
                <>
                  <Square className="w-4 h-4 fill-current" />
                  <span>إيقاف الصوت</span>
                </>
              ) : (
                <>
                  <Volume2 className="w-4 h-4 text-[#E2B773]" />
                  <span>الاستماع للقصة</span>
                </>
              )}
            </button>

            {/* Ambient sound cue */}
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400">
              <Waves className={`w-3 h-3 ${isPlayingAudio ? 'text-[#E2B773] animate-pulse' : 'text-slate-500'}`} />
              <span>مؤثرات المشهد:</span>
              <span className="text-[#E2B773] font-medium">{ambientPreset.icon} {ambientPreset.name.split(' ')[0]}</span>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation CTA Controls */}
      <footer className="relative z-10 px-6 pb-6 pt-2 flex items-center justify-between gap-3 max-w-lg mx-auto w-full">
        {currentSceneIndex > 0 ? (
          <button
            onClick={handlePrev}
            className="flex-1 h-12 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 font-bold text-sm flex items-center justify-center gap-2 border border-slate-700 active:scale-98 transition-all"
          >
            <ArrowRight className="w-4 h-4" />
            <span>السابق</span>
          </button>
        ) : (
          <div className="flex-1" />
        )}

        <button
          onClick={handleNext}
          className="flex-1 h-12 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#E2B773]/20 active:scale-98 transition-all"
        >
          {currentSceneIndex < totalScenes - 1 ? (
            <>
              <span>التالي</span>
              <ArrowLeft className="w-4 h-4" />
            </>
          ) : (
            <>
              <BookOpen className="w-4 h-4" />
              <span>صفحة الحديث وتخريجه</span>
            </>
          )}
        </button>
      </footer>
    </div>
  );
};
