import React, { useState, useEffect, useRef } from 'react';
import { HadithItem } from '../types/hadith';
import { audioEngine, SOLEMN_VOICE, cleanStoryContentForSpeech } from '../utils/audioService';
import { ambientEngine, detectAmbientContext, AMBIENT_PRESETS, AmbientContextType } from '../utils/ambientSoundService';
import { mosqueMinaretImage } from '../data/hadiths';
import { getSavedLanguage } from '../utils/languageService';
import { translateArabicToEnglish } from '../utils/translationService';
import {
  X,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Sparkles,
  BookOpen,
  Waves
} from 'lucide-react';

interface AudioPlayerModalProps {
  hadith: HadithItem;
  isOpen?: boolean;
  onClose: () => void;
}

export const AudioPlayerModal: React.FC<AudioPlayerModalProps> = ({
  hadith,
  isOpen = true,
  onClose
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [playMode, setPlayMode] = useState<'story' | 'hadith'>('story');
  const [progressPercent, setProgressPercent] = useState(0);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [durationSec, setDurationSec] = useState(0);
  const progressBarRef = useRef<HTMLDivElement>(null);

  // Contextual Ambient sound state
  const detectedContext = detectAmbientContext(hadith);
  const [ambientType, setAmbientType] = useState<AmbientContextType>(detectedContext);
  const [isAmbientMuted, setIsAmbientMuted] = useState<boolean>(ambientEngine.getIsMuted());
  const [ambientVolume, setAmbientVolume] = useState<number>(ambientEngine.getVolume());
  const [showAmbientSettings, setShowAmbientSettings] = useState<boolean>(false);

  // If closed, don't render
  if (isOpen === false) return null;

  // Prepare full story text vs hadith text directly without title prefixes
  const storyText = cleanStoryContentForSpeech(
    hadith.scenes && hadith.scenes.length > 0
      ? hadith.scenes.map(s => s.content).join(' ')
      : hadith.context || hadith.hadith_text
  );

  const directHadithText = cleanStoryContentForSpeech(hadith.hadith_text);
  const currentTextToPlay = playMode === 'story' ? storyText : directHadithText;

  const handleTogglePlay = () => {
    if (isPlaying) {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
      setIsPlaying(false);
      setProgressPercent(0);
      setCurrentTimeSec(0);
    } else {
      setIsPlaying(true);
      // Play contextual ambient sound layer alongside narration
      ambientEngine.play(ambientType);

      const language = getSavedLanguage();
      void (async () => {
        const spokenText = language === 'en' ? await translateArabicToEnglish(currentTextToPlay) : currentTextToPlay;
        audioEngine.reciteHadith(spokenText, {
        pitch: SOLEMN_VOICE.pitch,
        speed: SOLEMN_VOICE.rate,
        onProgress: (progress, current, duration) => {
          setProgressPercent(progress);
          setCurrentTimeSec(current);
          setDurationSec(duration);
        },
        onEnd: () => {
          setIsPlaying(false);
          ambientEngine.stop();
          setProgressPercent(0);
          setCurrentTimeSec(0);
        },
        onError: () => {
          setIsPlaying(false);
          ambientEngine.stop();
        },
          language,
        });
      })();
    }
  };

  const handleSeekClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressBarRef.current) return;
    const rect = progressBarRef.current.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const newPercent = ratio * 100;
    setProgressPercent(newPercent);
    audioEngine.seekPercent(newPercent);
  };

  const handleSwitchMode = (newMode: 'story' | 'hadith') => {
    if (playMode === newMode) return;
    if (isPlaying) {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
      setIsPlaying(false);
    }
    setProgressPercent(0);
    setCurrentTimeSec(0);
    setPlayMode(newMode);
  };

  const handleToggleAmbientMute = () => {
    const nextMuted = ambientEngine.toggleMute();
    setIsAmbientMuted(nextMuted);
  };

  const handleChangeAmbientType = (type: AmbientContextType) => {
    setAmbientType(type);
    if (isPlaying) {
      ambientEngine.play(type);
    }
  };

  const handleChangeAmbientVolume = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setAmbientVolume(newVol);
    ambientEngine.setVolume(newVol);
  };

  useEffect(() => {
    return () => {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
    };
  }, []);

  const activeAmbientPreset = AMBIENT_PRESETS[ambientType] || AMBIENT_PRESETS.sanctuary;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]">
              <Volume2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-200 block">مشغل الاستماع الوقور</span>
              <span className="text-[10px] text-[#E2B773] font-medium">صوت وقور عميق + مؤثرات بيئية</span>
            </div>
          </div>
          <button
            onClick={() => {
              audioEngine.stopSpeaking();
              ambientEngine.stop();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col items-center">
          {/* Cover Art / Mosque Visualizer */}
          <div className="relative w-44 h-44 rounded-2xl overflow-hidden mb-3 border border-slate-700 shadow-xl group">
            <img
              src={mosqueMinaretImage}
              alt={hadith.topic}
              className={`w-full h-full object-cover transition-transform duration-700 ${isPlaying ? 'scale-110 brightness-90' : 'scale-100 brightness-75'}`}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D131F] via-transparent to-transparent opacity-80" />

            {/* Pulsing visualizer circle */}
            {isPlaying && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full border-2 border-[#E2B773]/60 animate-ping opacity-60" />
                <div className="w-28 h-28 rounded-full border border-[#E2B773]/30 animate-pulse opacity-40" />
              </div>
            )}

            <div className="absolute bottom-2.5 right-2.5 left-2.5 text-center">
              <span className="text-[10px] font-mono tracking-wider text-[#E2B773] uppercase block">
                {hadith.hadith_number ? `حديث رقم ${hadith.hadith_number}` : 'الحديث النبوي'}
              </span>
              <span className="text-xs font-bold text-white line-clamp-1">
                {hadith.topic}
              </span>
            </div>
          </div>

          {/* Ambient Sound Layer Status Pill */}
          <div className="w-full mb-3">
            <div className="flex items-center justify-between px-3 py-1.5 rounded-xl bg-[#0D131F] border border-amber-900/30">
              <button
                onClick={() => setShowAmbientSettings(!showAmbientSettings)}
                className="flex items-center gap-1.5 text-[11px] text-[#E2B773] hover:text-amber-200 transition-colors font-medium text-right"
                title="تخصيص المؤثر الصوتي البيئي"
              >
                <Waves className={`w-3.5 h-3.5 ${isPlaying && !isAmbientMuted ? 'animate-pulse text-[#E2B773]' : 'text-slate-400'}`} />
                <span>مؤثر القصة:</span>
                <span className="font-bold text-white">{activeAmbientPreset.icon} {activeAmbientPreset.name}</span>
              </button>

              <button
                onClick={handleToggleAmbientMute}
                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all ${
                  isAmbientMuted
                    ? 'bg-red-950/40 text-red-400 border border-red-800/40'
                    : 'bg-[#E2B773]/15 text-[#E2B773] border border-[#E2B773]/30 hover:bg-[#E2B773]/25'
                }`}
                title={isAmbientMuted ? 'تشغيل المؤثرات البيئية' : 'كتم المؤثرات البيئية'}
              >
                {isAmbientMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Expandable Ambient Settings Tray */}
            {showAmbientSettings && (
              <div className="mt-2 p-3 bg-[#0D131F]/90 rounded-xl border border-slate-800 animate-fadeIn space-y-2.5">
                <div className="flex items-center justify-between text-[10px] text-slate-300">
                  <span>اختر نمط الأجواء (Ambient):</span>
                  <span className="text-amber-400/80">{activeAmbientPreset.description}</span>
                </div>

                <div className="grid grid-cols-3 gap-1">
                  {(Object.keys(AMBIENT_PRESETS) as AmbientContextType[]).map((key) => {
                    const preset = AMBIENT_PRESETS[key];
                    const isSelected = ambientType === key;
                    return (
                      <button
                        key={key}
                        onClick={() => handleChangeAmbientType(key)}
                        className={`p-1.5 rounded-lg text-[10px] flex items-center justify-center gap-1 transition-all ${
                          isSelected
                            ? 'bg-[#E2B773] text-[#0D131F] font-black shadow-sm'
                            : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700 hover:text-white'
                        }`}
                      >
                        <span>{preset.icon}</span>
                        <span className="truncate">{preset.name.split(' ')[0]}</span>
                      </button>
                    );
                  })}
                </div>

                <div className="flex items-center gap-2 pt-1 border-t border-slate-800/60">
                  <span className="text-[10px] text-slate-400 shrink-0">شدة المؤثر:</span>
                  <input
                    type="range"
                    min="0.05"
                    max="0.5"
                    step="0.02"
                    value={ambientVolume}
                    onChange={handleChangeAmbientVolume}
                    className="w-full accent-[#E2B773] h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <span className="text-[10px] font-mono text-slate-400">{Math.round(ambientVolume * 200)}%</span>
                </div>
              </div>
            )}
          </div>

          {/* Mode Switcher Tabs */}
          <div className="flex bg-[#0D131F] p-1 rounded-xl border border-slate-800 w-full mb-3">
            <button
              onClick={() => handleSwitchMode('story')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                playMode === 'story'
                  ? 'bg-[#E2B773] text-[#0D131F] shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              الاستماع للقصة
            </button>
            <button
              onClick={() => handleSwitchMode('hadith')}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                playMode === 'hadith'
                  ? 'bg-[#E2B773] text-[#0D131F] shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              استماع الحديث
            </button>
          </div>

          {/* نص الحديث مكتوب فوق الشريط الصوتي عند وضع الحديث */}
          {playMode === 'hadith' && (
            <div className="w-full bg-[#0D131F] p-4 rounded-2xl border border-[#E2B773]/30 mb-3 text-center">
              <span className="text-[10px] text-[#E2B773] font-bold block mb-1.5 flex items-center justify-center gap-1">
                <Sparkles className="w-3 h-3" />
                <span>نص الحديث الشريف</span>
              </span>
              <p className="font-hadith text-base sm:text-lg font-bold text-amber-100 leading-loose max-h-36 overflow-y-auto px-1 selection:bg-[#E2B773]/30">
                «{directHadithText}»
              </p>
            </div>
          )}

          {/* Interactive Timeline Scrubber (الشريط الصوتي) */}
          <div className="w-full mt-1 bg-[#0D131F] p-3 rounded-2xl border border-slate-800/80">
            <div
              ref={progressBarRef}
              onClick={handleSeekClick}
              className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden cursor-pointer relative group"
            >
              <div
                className="bg-gradient-to-r from-[#C99846] to-[#F3D59B] h-full transition-all duration-150 relative"
                style={{ width: `${progressPercent}%` }}
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
            </div>

            <div className="flex justify-between items-center text-[10px] font-mono text-slate-400 mt-2 px-1">
              <span className="text-[#E2B773] font-sans font-bold flex items-center gap-1">
                {isPlaying ? (
                  <>
                    <span>{playMode === 'story' ? 'استماع القصة جارٍ...' : 'استماع الحديث جارٍ...'}</span>
                    {!isAmbientMuted && (
                      <span className="text-[9px] text-amber-300/80 font-normal">({activeAmbientPreset.icon} مفعّل)</span>
                    )}
                  </>
                ) : (
                  'وقور عميق'
                )}
              </span>
              <span className="tracking-wider">
                {Math.floor(currentTimeSec / 60)}:{Math.floor(currentTimeSec % 60).toString().padStart(2, '0')} / {Math.floor(durationSec / 60)}:{Math.floor(durationSec % 60).toString().padStart(2, '0')}
              </span>
            </div>
          </div>

          {/* Play / Pause Primary Action */}
          <div className="flex items-center justify-center gap-4 mt-4 w-full">
            <button
              onClick={handleTogglePlay}
              className="px-8 py-3.5 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] active:scale-95 text-[#0D131F] font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#E2B773]/30 transition-all"
              title={isPlaying ? 'إيقاف مؤقت' : (playMode === 'story' ? 'الاستماع للقصة' : 'استماع الحديث')}
            >
              {isPlaying ? (
                <>
                  <Pause className="w-5 h-5 fill-current" />
                  <span>إيقاف</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                  <span>{playMode === 'story' ? 'الاستماع للقصة' : 'استماع الحديث'}</span>
                </>
              )}
            </button>
          </div>

          {/* Clarification Note */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 w-full text-center">
            <span className="text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 text-[#E2B773]" />
              <span>نبرة صوت واحدة رصينة مع طبقة مؤثرات بيئية خفيفة هادئة</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

