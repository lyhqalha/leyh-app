#!/usr/bin/env bash
set -euo pipefail

# Android 10+ only.
if [ -f android/variables.gradle ]; then
  sed -E -i 's/minSdkVersion = [0-9]+/minSdkVersion = 29/' android/variables.gradle
fi

if [ -f android/app/build.gradle ]; then
  if grep -Eq 'minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+' android/app/build.gradle; then
    sed -E -i 's/minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+/minSdk\1 = 29/g' android/app/build.gradle
  elif grep -q 'defaultConfig {' android/app/build.gradle; then
    sed -i '/defaultConfig {/a\        minSdk 29' android/app/build.gradle
  fi
fi

# Bundle notification audio in Android's raw resources.
mkdir -p android/app/src/main/res/raw
cp resources/salawat.wav android/app/src/main/res/raw/salawat.wav
cp resources/notification.wav android/app/src/main/res/raw/notification.wav

# Force immersive fullscreen so the app opens without a phone-frame/status/nav-bar layout.
MAIN_JAVA_DIR="android/app/src/main/java/com/leyhqalha/leyh"
mkdir -p "$MAIN_JAVA_DIR"
find android/app/src/main/java -type f \( -name 'MainActivity.java' -o -name 'MainActivity.kt' \) -delete
cat > "$MAIN_JAVA_DIR/MainActivity.java" <<'JAVA'
package com.leyhqalha.leyh;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private static final String DAILY_CHANNEL_ID = "daily-reading-v3";
    private static final String SALAWAT_CHANNEL_ID = "salawat-reminder-v3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        makeFullscreen();
        createNotificationChannels();
    }

    private void makeFullscreen() {
        Window window = getWindow();

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);

            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(
                    WindowInsets.Type.statusBars()
                    | WindowInsets.Type.navigationBars()
                );
                controller.setSystemBarsBehavior(
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            window.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            );
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager =
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager == null) return;

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        Uri dailySound = Uri.parse(
            "android.resource://" + getPackageName() + "/" + R.raw.notification
        );

        Uri salawatSound = Uri.parse(
            "android.resource://" + getPackageName() + "/" + R.raw.salawat
        );

        NotificationChannel daily = new NotificationChannel(
            DAILY_CHANNEL_ID,
            "تذكير القراءة اليومية",
            NotificationManager.IMPORTANCE_HIGH
        );
        daily.setDescription("تنبيهات يومية لقراءة حديث اليوم وقصته");
        daily.enableVibration(true);
        daily.setSound(dailySound, audioAttributes);
        manager.createNotificationChannel(daily);

        NotificationChannel salawat = new NotificationChannel(
            SALAWAT_CHANNEL_ID,
            "الصلاة على النبي ﷺ",
            NotificationManager.IMPORTANCE_HIGH
        );
        salawat.setDescription("تذكير صوتي للصلاة على النبي محمد ﷺ");
        salawat.enableVibration(true);
        salawat.setSound(salawatSound, audioAttributes);
        manager.createNotificationChannel(salawat);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            makeFullscreen();
        }
    }
}
JAVA
