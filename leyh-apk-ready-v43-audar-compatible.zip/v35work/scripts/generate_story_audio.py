#!/usr/bin/env python3
"""Generate permanent story MP3s with Audar-TTS-V1-Flash GGUF.

The large model runs only on the GitHub Actions runner and is not copied into
Android assets. Dependencies are installed and pinned by the workflow, not here.
"""
from pathlib import Path
import re
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "story-audio"
DATA_FILE = ROOT / "src" / "data" / "additionalHadiths.ts"
REF = ROOT / ".audar-reference.wav"
REF_URL = "https://huggingface.co/audarai/Audar-TTS-V1-Flash/resolve/main/samples/demo_male_1_ar.wav"
REF_TEXT = "لا يمكنني الانتظار لأخبرك — [excited] لقد أنجزنا المشروع أخيراً بعد كلّ هذا التعب، [laughs] وصدّقني، إنه أجمل شعورٍ على الإطلاق!"
MODEL_REPO = "audarai/Audar-TTS-V1-Flash"
SAMPLE_RATE = 24000


def scenes():
    if not DATA_FILE.is_file():
        raise FileNotFoundError(f"Hadith story data file missing: {DATA_FILE}")
    text = DATA_FILE.read_text(encoding="utf-8")
    blocks = re.findall(
        r"id:\s*'([^']+)'(?P<body>.*?)(?=\n\s*\},\n\n\s*//|\n\s*\},\n\s*//|\n\s*\}\s*\n\s*\])",
        text,
        re.S,
    )
    found = []
    for hid, body in blocks:
        for n, audio_text in re.findall(
            r"sceneNumber:\s*(\d+).*?audioText:\s*'((?:[^'\\]|\\.)*)'",
            body,
            re.S,
        ):
            audio_text = audio_text.replace("\\'", "'").replace("\\n", " ").strip()
            if audio_text:
                found.append((hid, int(n), audio_text))
    if not found:
        raise RuntimeError("No story scenes found in src/data/additionalHadiths.ts")
    return found


def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    import torch
    import soundfile as sf
    from huggingface_hub import hf_hub_download
    from llama_cpp import Llama
    from neucodec import NeuCodec

    OUT.mkdir(parents=True, exist_ok=True)
    items = scenes()
    print(f"Found {len(items)} permanent story scenes", flush=True)

    if not REF.exists():
        print("Downloading Audar demo_male_1 Arabic reference...", flush=True)
        urllib.request.urlretrieve(REF_URL, REF)
    if not REF.is_file() or REF.stat().st_size < 10000:
        raise RuntimeError("Audar Arabic reference download is missing or too small")

    print("Downloading/loading Audar Flash GGUF...", flush=True)
    gguf = hf_hub_download(MODEL_REPO, "Audar-TTS-V1-Flash-Q4_K_M.gguf")
    llm = Llama(model_path=gguf, n_ctx=4096, n_gpu_layers=0, verbose=False)
    codec = NeuCodec.from_pretrained("neuphonic/neucodec").eval()

    # Official Audar GGUF protocol: reference speech tokens + target text.
    with torch.no_grad():
        ref_codes_tensor = codec.encode_code(str(REF))
    ref_codes = ref_codes_tensor.squeeze().tolist()
    if not isinstance(ref_codes, list):
        ref_codes = [int(ref_codes)]
    ref = "".join(f"<|speech_{int(code)}|>" for code in ref_codes)
    prompt_prefix = (
        "user: Convert the text to speech:\n"
        f"<|REF_TEXT_START|>{REF_TEXT}<|REF_TEXT_END|>\n"
        f"<|REF_SPEECH_START|>{ref}<|REF_SPEECH_END|>\n"
    )
    end_token = llm.tokenize(b"<|TARGET_CODES_END|>", add_bos=False, special=True)[0]
    print("Audar model loaded. Generating scenes...", flush=True)

    for index, (hid, n, text) in enumerate(items, 1):
        out_dir = OUT / hid
        out_dir.mkdir(parents=True, exist_ok=True)
        mp3_path = out_dir / f"scene-{n}.mp3"
        wav_path = out_dir / f"scene-{n}.wav"
        if mp3_path.is_file() and mp3_path.stat().st_size > 10000:
            print(f"[{index}/{len(items)}] exists: {mp3_path}", flush=True)
            continue

        # Add a restrained storyteller cue; keep the story's Arabic text intact.
        target = f"[exhales] {text}"
        prompt = (
            prompt_prefix
            + f"<|TARGET_TEXT_START|>{target}<|TARGET_TEXT_END|>\n"
            + "assistant:<|TARGET_CODES_START|>"
        )
        toks = llm.tokenize(prompt.encode("utf-8"), add_bos=False, special=True)
        generated_ids = []
        for token_id in llm.generate(
            toks, temp=0.75, top_k=40, top_p=0.9, repeat_penalty=1.1
        ):
            if token_id == end_token or len(generated_ids) >= 4096:
                break
            generated_ids.append(token_id)
        generated = llm.detokenize(generated_ids, special=True).decode("utf-8", "ignore")
        codes = [int(x) for x in re.findall(r"<\|speech_(\d+)\|>", generated)]
        if not codes:
            raise RuntimeError(f"Audar generated no speech codes for {hid} scene {n}")

        with torch.no_grad():
            wav_tensor = codec.decode_code(torch.tensor(codes, dtype=torch.long)[None, None, :]).cpu()
        wav = wav_tensor[0, 0, :].numpy()
        sf.write(str(wav_path), wav, SAMPLE_RATE)
        run([
            "ffmpeg", "-y", "-loglevel", "error", "-i", str(wav_path),
            "-codec:a", "libmp3lame", "-b:a", "96k", str(mp3_path),
        ])
        wav_path.unlink(missing_ok=True)
        if not mp3_path.is_file() or mp3_path.stat().st_size <= 10000:
            raise RuntimeError(f"MP3 validation failed for {hid} scene {n}")
        print(f"[{index}/{len(items)}] generated: {mp3_path}", flush=True)

    count = sum(1 for p in OUT.rglob("*.mp3") if p.stat().st_size > 10000)
    print(f"Validated story MP3 files: {count}", flush=True)
    if count < len(items):
        raise RuntimeError(f"Expected at least {len(items)} MP3 files, found {count}")
    print("Story audio generation complete.", flush=True)


if __name__ == "__main__":
    main()
