export type ContentLanguage = 'ar' | 'en';

// Intentionally offline: the app never calls a browser/Google translation service.
export async function translateArabicToEnglish(text: string): Promise<string> {
  return text || '';
}
