export type AppLanguage = 'ar' | 'en';

const LANGUAGE_KEY = 'leyh_app_language';

export const BUILD_LANGUAGE: AppLanguage =
  import.meta.env.VITE_APP_LANGUAGE === 'en' ? 'en' : 'ar';

export function getSavedLanguage(): AppLanguage {
  try {
    const saved = localStorage.getItem(LANGUAGE_KEY);
    if (saved === 'ar' || saved === 'en') return saved;
  } catch {}
  return BUILD_LANGUAGE;
}

export function setSavedLanguage(language: AppLanguage) {
  try { localStorage.setItem(LANGUAGE_KEY, language); } catch {}
}

export function applyLanguageDirection(language: AppLanguage) {
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'en' ? 'ltr' : 'rtl';
  document.body.dir = language === 'en' ? 'ltr' : 'rtl';
}
