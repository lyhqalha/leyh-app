import React from 'react';

/** Browser translation is intentionally disabled. Language is part of the APK build. */
export const GoogleTranslate: React.FC<{ language: 'ar' | 'en' }> = () => null;
