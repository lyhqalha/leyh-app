import { useEffect } from 'react';
import { getSavedLanguage } from '../utils/languageService';

// Local, bundled UI translations only. No browser translation and no network calls.
const DICT: Record<string, string> = {
  'الرئيسية':'Home','المحفوظات':'Saved','حديث اليوم':'Daily Hadith','التصنيفات':'Categories','البحث':'Search',
  'الإعدادات':'Settings','إعدادات التطبيق':'App Settings','إغلاق':'Close','رجوع':'Back','حفظ':'Save','محفوظ':'Saved',
  'حفظ الحديث':'Save Hadith','إزالة من المحفوظات':'Remove from Saved','إزالة الحفظ':'Remove Saved','مشاركة الحديث':'Share Hadith',
  'نسخ النص':'Copy Text','تم النسخ!':'Copied!','جارٍ الحفظ...':'Saving...','حفظ الصورة':'Save Image',
  'حديث اليوم':'Daily Hadith','اليوم السابق':'Previous Day','اليوم التالي':'Next Day','الحديث النبوي':'Prophetic Hadith',
  'استماع الحديث':'Listen to Hadith','استماع الحديث جارٍ...':'Playing Hadith...','الاستماع للقصة':'Listen to Story','استماع القصة جارٍ...':'Playing Story...',
  'إيقاف مؤقت':'Pause','إيقاف استماع الحديث':'Stop Hadith Audio','جارٍ استماع الحديث...':'Playing Hadith...','شريط استماع الحديث':'Hadith Audio Bar',
  'الافتراضي':'Default','وضع النهار':'Day Mode','مظلم فائق':'Ultra Dark','وضع النهار يوفر خلفية فاتحة وألواناً نضرة مريحة جداً للقراءة في ضوء النهار وأثناء الصباح.':'Day Mode provides a bright, comfortable reading appearance for daytime use.',
  'اللغة':'Language','العربية':'Arabic','الإنجليزية':'English','English':'English','العربي':'Arabic',
  'مظهر التطبيق (الوضع)':'App Appearance','تذكير القراءة اليومي':'Daily Reading Reminder','تذكير الصلاة على النبي ﷺ':'Salawat Reminder',
  'تفعيل أو تعطيل التذكير اليومي':'Enable or disable the daily reminder','تفعيل أو تعطيل تذكير الصلاة على النبي ﷺ':'Enable or disable the Salawat reminder',
  'تجربة الإشعار الآن':'Test Notification Now','صباحاً':'Morning','عصراً':'Afternoon','فجراً':'Dawn','مساءً':'Evening',
  'طبيعي':'Normal','كبير':'Large','كبير جداً':'Extra Large','تخصيص المؤثر الصوتي البيئي':'Ambient Sound','تشغيل المؤثرات البيئية':'Enable ambient sounds','كتم المؤثرات البيئية':'Mute ambient sounds',
  'الرئيسية':'Home','البحث':'Search','التصنيفات':'Categories','المحفوظات':'Saved','المشهد النبوي':'Prophetic Scene',
  'ابحث في نص الحديث أو الراوي أو الموضوع...':'Search hadith text, narrator, or topic...','الكل':'All','الحديث':'Hadith','الراوي':'Narrator','الموضوع':'Topic','الكلمات المفتاحية':'Keywords',
  'صحيح البخاري':'Sahih al-Bukhari','المسجد النبوي':'Prophet’s Mosque','قال رسول الله ﷺ':'The Messenger of Allah ﷺ said','كل حديث قصة قبل أن يكون كلمة':'Every hadith has a story before it becomes words',
  'الدعاء':'Supplication','الصلاة':'Prayer','خلفية قصة الحديث':'Hadith Story Background','رمضان':'Ramadan',
  'تجربة الإشعار الآن':'Test Notification Now','تم إرسال إشعار تجريبي بنجاح!':'Test notification sent successfully!',
  'إذا ظهر هذا التنبيه، فالإشعارات تعمل بشكل صحيح ✅':'If this alert appears, notifications are working correctly ✅',
  'إشعار تجريبي - «ليه قالها؟»':'Test Notification - “Why Was It Said?”','اختبار تذكير القراءة':'Test Reading Reminder',
  'تذكير القراءة اليومي - حديث اليوم':'Daily Reading Reminder - Today’s Hadith','حان موعد تدبر حديث اليوم الشريف وقراءة قصته النبوية!':'It is time to reflect on today’s hadith and its prophetic story!',
  'سيظهر إشعار الجهاز خلال ثوانٍ قليلة.':'The device notification will appear in a few seconds.',
  'وقور عميق':'Deep & Solemn','شريط صوتي (وقور عميق)':'Audio Bar (Deep & Solemn)',
  'مجموعة من الأحاديث النبوية الشريفة المتعلقة بهذا الباب':'A collection of noble prophetic hadiths related to this topic',
  'لا تنسَ مطوّر التطبيق من صالح دعائك':'Please remember the app developer in your sincere prayers',
};

const SKIP = new Set(['SCRIPT','STYLE','NOSCRIPT','TEXTAREA','INPUT','SELECT','OPTION']);

function translateNode(node: Text) {
  const parent = node.parentElement;
  if (!parent || SKIP.has(parent.tagName)) return;
  const raw = node.textContent || '';
  const trimmed = raw.trim();
  if (!trimmed || !/^[\u0600-\u06FF\s\d،؛؟«» ﷺ٪%.,:!?()\-]+$/.test(trimmed)) return;
  const translated = DICT[trimmed];
  if (!translated) return;
  const leading = raw.match(/^\s*/)?.[0] || '';
  const trailing = raw.match(/\s*$/)?.[0] || '';
  node.textContent = leading + translated + trailing;
  parent.dataset.localEnglish = '1';
}

export function EmbeddedEnglishTranslator() {
  useEffect(() => {
    if (getSavedLanguage() !== 'en') return;
    const translate = () => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const nodes: Text[] = [];
      let n: Node | null;
      while ((n = walker.nextNode())) nodes.push(n as Text);
      nodes.forEach(translateNode);
    };
    const timer = window.setTimeout(translate, 30);
    const observer = new MutationObserver(() => window.setTimeout(translate, 0));
    observer.observe(document.body, { childList: true, subtree: true });
    return () => { window.clearTimeout(timer); observer.disconnect(); };
  }, []);
  return null;
}
