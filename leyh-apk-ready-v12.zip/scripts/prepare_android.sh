#!/usr/bin/env bash
set -euo pipefail

# Android 10+ only.
if [ -f android/variables.gradle ]; then
  sed -E -i 's/minSdkVersion = [0-9]+/minSdkVersion = 29/' android/variables.gradle
fi

if [ -f android/app/build.gradle ]; then
  if grep -Eq 'minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+' android/app/build.gradle; then
    sed -E -i 's/minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+/minSdk\1 = 29/g' android/app/build.gradle
  elif grep -q 'defaultConfig {' android/app/build.gradle; then
    sed -i '/defaultConfig {/a\        minSdk 29' android/app/build.gradle
  fi
fi

# Bundle notification audio in Android's raw resources.
mkdir -p android/app/src/main/res/raw
cp resources/salawat.wav android/app/src/main/res/raw/salawat.wav
cp resources/notification.wav android/app/src/main/res/raw/notification.wav

# Force immersive fullscreen so the app opens without a phone-frame/status/nav-bar layout.
MAIN_JAVA_DIR="android/app/src/main/java/com/leyhqalha/leyh"
mkdir -p "$MAIN_JAVA_DIR"
find android/app/src/main/java -type f \( -name 'MainActivity.java' -o -name 'MainActivity.kt' \) -delete
cat > "$MAIN_JAVA_DIR/MainActivity.java" <<'JAVA'
package com.leyhqalha.leyh;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        hideSystemBars();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }
}
JAVA
