import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const DAILY_REMINDER_ID = 1001;
const TEST_REMINDER_ID = 1002;
const NOTIFICATION_CHANNEL_ID = 'daily-reading-v2';
const NOTIFICATION_SOUND = 'notification.wav';
const SALAWAT_CHANNEL_ID = 'salawat-reminder-v2';
const SALAWAT_SOUND = 'salawat.wav';
const SALAWAT_ID = 2001;

const TITLE = 'تذكير القراءة اليومية - «ليه قالها؟»';
const BODY = 'حان موعد حديث اليوم وقصته النبوية 📖✨';

async function ensureChannel() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.createChannel({
      id: NOTIFICATION_CHANNEL_ID,
      name: 'تذكير القراءة اليومية',
      description: 'تنبيهات يومية لقراءة حديث اليوم وقصته',
      importance: 5,
      visibility: 1,
      sound: NOTIFICATION_SOUND,
      vibration: true,
    });
  } catch {
    // The channel may already exist or the platform may not support channels.
  }
}

async function ensureSalawatChannel() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.createChannel({
      id: SALAWAT_CHANNEL_ID,
      name: 'الصلاة على النبي ﷺ',
      description: 'تذكير صوتي للصلاة على النبي محمد ﷺ',
      importance: 5,
      visibility: 1,
      sound: SALAWAT_SOUND,
      vibration: true,
    });
  } catch {
    // The channel may already exist.
  }
}

async function requestNativePermission(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  try {
    const current = await LocalNotifications.checkPermissions();
    if (current.display === 'granted') return true;
    const requested = await LocalNotifications.requestPermissions();
    return requested.display === 'granted';
  } catch {
    return false;
  }
}

function nextDateForTime(time: string): Date {
  const [hours, minutes] = time.split(':').map(Number);
  const next = new Date();
  next.setSeconds(0, 0);
  next.setHours(Number.isFinite(hours) ? hours : 9, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  if (next.getTime() <= Date.now()) next.setDate(next.getDate() + 1);
  return next;
}

export async function scheduleDailyReadingReminder(time: string): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureChannel();
  try {
    await LocalNotifications.cancel({ notifications: [{ id: DAILY_REMINDER_ID }] });
  } catch {
    // Nothing to cancel is fine.
  }
  try {
    await LocalNotifications.schedule({
      notifications: [{
        id: DAILY_REMINDER_ID,
        title: TITLE,
        body: BODY,
        channelId: NOTIFICATION_CHANNEL_ID,
        sound: NOTIFICATION_SOUND,
        isExactNotification: false,
        schedule: {
          at: nextDateForTime(time),
          repeats: true,
          allowWhileIdle: true,
        },
        autoCancel: true,
      }],
    });
    return true;
  } catch {
    return false;
  }
}

export async function cancelDailyReadingReminder(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.cancel({ notifications: [{ id: DAILY_REMINDER_ID }] });
  } catch {
    // Already canceled or unavailable.
  }
}

export async function sendTestReadingReminder(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureChannel();
  try {
    await LocalNotifications.cancel({ notifications: [{ id: TEST_REMINDER_ID }] });
  } catch {
    // Nothing to cancel is fine.
  }
  try {
    await LocalNotifications.schedule({
      notifications: [{
        id: TEST_REMINDER_ID,
        title: 'إشعار تجريبي - «ليه قالها؟»',
        body: 'إذا ظهر هذا التنبيه خارج التطبيق، فالإشعارات تعمل بشكل صحيح ✅',
        channelId: NOTIFICATION_CHANNEL_ID,
        sound: NOTIFICATION_SOUND,
        isExactNotification: false,
        schedule: { at: new Date(Date.now() + 2500), allowWhileIdle: true },
        autoCancel: true,
      }],
    });
    return true;
  } catch {
    return false;
  }
}


const SALAWAT_ID_BASE = 2001;
const SALAWAT_SLOTS = 336;

function buildSalawatSchedule(intervalMinutes: 30 | 60) {
  const count = intervalMinutes === 30 ? SALAWAT_SLOTS : 168;
  const notifications = [];
  const start = Date.now() + intervalMinutes * 60 * 1000;

  for (let i = 0; i < count; i++) {
    notifications.push({
      id: SALAWAT_ID_BASE + i,
      title: 'صلِّ على محمد ﷺ',
      body: 'اللهم صلِّ وسلم وبارك على نبينا محمد ﷺ',
      channelId: SALAWAT_CHANNEL_ID,
      sound: SALAWAT_SOUND,
      isExactNotification: false,
      schedule: {
        at: new Date(start + i * intervalMinutes * 60 * 1000),
        allowWhileIdle: true,
      },
      autoCancel: true,
    });
  }
  return notifications;
}

export async function scheduleSalawatReminder(intervalMinutes: 30 | 60): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureSalawatChannel();

  try {
    await LocalNotifications.cancel({
      notifications: Array.from({ length: SALAWAT_SLOTS }, (_, i) => ({ id: SALAWAT_ID_BASE + i })),
    });
  } catch {}

  try {
    await LocalNotifications.schedule({
      notifications: buildSalawatSchedule(intervalMinutes),
    });
    return true;
  } catch {
    return false;
  }
}

export async function cancelSalawatReminder(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.cancel({
      notifications: Array.from({ length: SALAWAT_SLOTS }, (_, i) => ({ id: SALAWAT_ID_BASE + i })),
    });
  } catch {}
}

export async function sendTestSalawatReminder(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureSalawatChannel();
  const testId = 2099;
  try {
    await LocalNotifications.cancel({ notifications: [{ id: testId }] });
  } catch {}
  try {
    await LocalNotifications.schedule({
      notifications: [{
        id: testId,
        title: 'صلِّ على محمد ﷺ',
        body: 'تذكير صوتي تجريبي',
        channelId: SALAWAT_CHANNEL_ID,
        sound: SALAWAT_SOUND,
        isExactNotification: false,
        schedule: { at: new Date(Date.now() + 5000), allowWhileIdle: true },
        autoCancel: true,
      }],
    });
    return true;
  } catch {
    return false;
  }
}
