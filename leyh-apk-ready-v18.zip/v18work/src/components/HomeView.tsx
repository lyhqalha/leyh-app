import React, { useMemo } from 'react';
import { HadithItem, ActiveTab } from '../types/hadith';
import { desertHeroImage } from '../data/hadiths';
import { getDailyHadith, formatShortArabicDate } from '../utils/dailyHadith';
import {
  Search,
  Settings,
  Play,
  Bookmark,
  LayoutGrid,
  Sparkles,
  Volume2,
  Share2,
  ChevronLeft,
  BookOpen,
  Calendar
} from 'lucide-react';

interface HomeViewProps {
  hadiths: HadithItem[];
  onOpenStory: (hadith: HadithItem) => void;
  onSelectHadith: (hadith: HadithItem) => void;
  onChangeTab: (tab: ActiveTab) => void;
  onOpenSettings: () => void;
  language?: 'ar' | 'en';
}

export const HomeView: React.FC<HomeViewProps> = ({
  hadiths,
  onOpenStory,
  onSelectHadith,
  onChangeTab,
  onOpenSettings,
  language = 'ar',
}) => {

  // Automatically rotates every single day across all 2000 hadiths
  const featuredHadith = useMemo(() => getDailyHadith(hadiths, new Date()), [hadiths]);
  const todayArabicDate = useMemo(() => formatShortArabicDate(new Date(), language), [language]);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto space-y-5">
      {/* Top Header */}
      <header className="flex items-center justify-between pt-2">
        <button
          onClick={() => onChangeTab('search')}
          className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
          title="البحث"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Center Logo Branding matching mockup */}
        <div className="text-center flex flex-col items-center">
          {/* Mosque Dome and Crescent symbol */}
          <div className="flex items-center justify-center text-[#E2B773] mb-0.5">
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C10.5 4 9 6.5 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 6.5 13.5 4 12 2ZM4 19V11C4 10.45 4.45 10 5 10H6V19H4ZM18 10H19C19.55 10 20 10.45 20 11V19H18V10ZM8 19V11.5C8 9.5 9.8 8 12 8C14.2 8 16 9.5 16 11.5V19H8ZM3 21H21V22H3V21Z" />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight leading-none">
            ليه قالها؟
          </h1>
          <p className="text-[11px] text-[#94A3B8] font-medium mt-1">
            كل حديث قصة قبل أن يكون كلمة
          </p>
        </div>

        {/* Header Actions: Settings only */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Featured Hero Card: حديث اليوم (matches mockup exactly) */}
      <div className="hero-card relative w-full rounded-3xl overflow-hidden border border-slate-800/80 shadow-2xl bg-[#131B2E]">
        {/* Desert artwork background */}
        <div className="relative w-full h-72 sm:h-80 overflow-hidden">
          <img
            src={desertHeroImage}
            alt="المشهد النبوي"
            className="w-full h-full object-cover filter brightness-[0.7]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131B2E] via-[#131B2E]/40 to-black/30" />

          {/* Badge */}
          <div className="absolute top-4 inset-x-0 flex justify-center z-10">
            <span className="px-4 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-[#E2B773]/40 text-xs text-[#E2B773] font-bold flex items-center gap-1.5 shadow-lg">
              <Calendar className="w-3.5 h-3.5 text-[#E2B773]" />
              <span>حديث اليوم · {todayArabicDate}</span>
            </span>
          </div>

          {/* Center Callout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 pt-10">
            {/* Topic pill */}
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#131B2E]/80 backdrop-blur-md border border-slate-700/80 text-[11px] font-semibold text-[#E2B773] mb-2">
              <Sparkles className="w-3 h-3" />
              <span>{featuredHadith.topic} · {featuredHadith.narrator}</span>
            </span>

            <h3 className="text-xl sm:text-2xl font-extrabold text-white mb-1.5 max-w-sm drop-shadow">
              قبل أن تقرأ الحديث...
            </h3>
            <p className="text-xs sm:text-sm text-slate-200 mb-5 font-medium drop-shadow max-w-md line-clamp-2 px-2 text-slate-300">
              {featuredHadith.context.slice(0, 95)}...
            </p>

            {/* Start Story CTA button */}
            <button
              onClick={() => onOpenStory(featuredHadith)}
              className="py-3 px-8 rounded-full bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-sm flex items-center gap-2 shadow-xl shadow-black/40 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>ابدأ قصة اليوم</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Access 3 Shortcuts (Matches mockup: المحفوظات / البحث / التصنيفات) */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => onChangeTab('saved')}
          className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 active:scale-95 transition-all group"
        >
          <div className="w-11 h-11 rounded-2xl bg-[#1E293B] group-hover:bg-[#E2B773]/15 flex items-center justify-center mb-2 text-[#E2B773] transition-colors">
            <Bookmark className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-200">المحفوظات</span>
        </button>

        <button
          onClick={() => onChangeTab('search')}
          className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 active:scale-95 transition-all group"
        >
          <div className="w-11 h-11 rounded-2xl bg-[#1E293B] group-hover:bg-[#E2B773]/15 flex items-center justify-center mb-2 text-[#E2B773] transition-colors">
            <Search className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-200">البحث</span>
        </button>

        <button
          onClick={() => onChangeTab('categories')}
          className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 active:scale-95 transition-all group"
        >
          <div className="w-11 h-11 rounded-2xl bg-[#1E293B] group-hover:bg-[#E2B773]/15 flex items-center justify-center mb-2 text-[#E2B773] transition-colors">
            <LayoutGrid className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-slate-200">التصنيفات</span>
        </button>
      </div>

      {/* Value Proposition Highlights Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#1E293B] to-[#131B2E] border border-slate-800 flex items-center justify-around text-center text-xs text-slate-300">
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">2000+</span>
          <span className="text-[10px] text-slate-400">حديث صحيح</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">5 مشاهد</span>
          <span className="text-[10px] text-slate-400">قصة تفاعلية</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">صوتيات</span>
          <span className="text-[10px] text-slate-400">راوية هادئة</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">مشاركة</span>
          <span className="text-[10px] text-slate-400">بطاقات مصممة</span>
        </div>
      </div>

      {/* Home page ends here: the full hadith library is available from Search and Categories. */}
      <div className="flex items-center justify-between px-1 pt-1 pb-2">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-[#E2B773]" />
          <span>قصص الأحاديث النبوية ({hadiths.length} قصة متوفرة)</span>
        </h3>
        <button
          onClick={() => onChangeTab('categories')}
          className="text-xs text-[#E2B773] font-semibold hover:underline flex items-center gap-0.5"
        >
          <span>عرض التصنيفات</span>
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
