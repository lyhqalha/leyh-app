import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { desertHeroImage } from '../data/hadiths';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { getDailyHadith, formatArabicDate } from '../utils/dailyHadith';
import { Sparkles, Calendar, BookOpen, ChevronRight, ChevronLeft, RotateCcw } from 'lucide-react';

interface DailyHadithViewProps {
  hadiths: HadithItem[];
  onOpenStory: (hadith: HadithItem) => void;
  onOpenDetail: (hadith: HadithItem) => void;
}

export const DailyHadithView: React.FC<DailyHadithViewProps> = ({
  hadiths,
  onOpenStory,
  onOpenDetail,
}) => {
  const [dayOffset, setDayOffset] = useState(0);

  // Pick hadith dynamically based on the exact calendar date
  const targetDate = new Date();
  targetDate.setDate(targetDate.getDate() + dayOffset);
  const hadith = getDailyHadith(hadiths, targetDate);
  const formattedDate = formatArabicDate(targetDate);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto flex flex-col items-center">
      
      {/* Top Header & Date Navigation */}
      <div className="w-full text-center mb-4">
        <h2 className="text-xl font-bold text-white mb-1">حديث اليوم</h2>
        
        {/* Date Selector Row */}
        <div className="flex items-center justify-center gap-3 mt-2">
          <button
            onClick={() => setDayOffset(prev => prev + 1)}
            disabled={dayOffset >= 0}
            className={`p-1.5 rounded-full bg-slate-800 transition-colors ${
              dayOffset >= 0 ? 'text-slate-600 cursor-not-allowed' : 'text-slate-300 hover:text-white'
            }`}
            title="اليوم التالي"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#131B2E] border border-slate-800 text-xs text-[#E2B773] font-medium">
            <Calendar className="w-3.5 h-3.5" />
            <span>{formattedDate}</span>
          </div>

          <button
            onClick={() => setDayOffset(prev => prev - 1)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white transition-colors"
            title="اليوم السابق"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>

        {dayOffset !== 0 && (
          <button
            onClick={() => setDayOffset(0)}
            className="mt-2 inline-flex items-center gap-1 text-[11px] font-bold text-[#E2B773] hover:underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>العودة لتاريخ اليوم</span>
          </button>
        )}
      </div>

      {/* Featured Card */}
      <div className="w-full rounded-3xl bg-[#131B2E] border border-slate-700/80 overflow-hidden shadow-2xl flex flex-col">
        
        {/* Landscape Image */}
        <div className="relative w-full h-48 sm:h-56 overflow-hidden">
          <img
            src={desertHeroImage}
            alt="حديث اليوم"
            className="w-full h-full object-cover filter brightness-[0.75]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131B2E] via-transparent to-black/30" />
          <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-[#0D131F]/80 backdrop-blur-md border border-white/10 text-xs text-[#E2B773] font-bold">
            قبس من النبوة
          </div>
        </div>

        {/* Card Body */}
        <div className="p-5 flex flex-col items-center text-center">
          
          {/* مكان الاستماع إلى الحديث: شريط صوتي وفوقه الحديث مكتوب */}
          <div className="w-full mb-4">
            <HadithReciterPlayer
              hadithText={hadith.hadith_text}
              narrator={hadith.narrator}
              source={hadith.source}
              variant="card"
              showText={true}
            />
          </div>

          {/* Metadata */}
          <div className="text-xs text-slate-400 space-y-1 mb-4 mt-1">
            <p className="text-[11px]">
              المصدر: <span className="text-slate-200">{hadith.source}</span> · رقم الحديث: {hadith.hadith_number} · درجة الحديث: <span className="text-emerald-400 font-semibold">{hadith.authenticity_grade}</span>
            </p>
          </div>

          {/* Primary Action Button: الاستماع للقصة */}
          <button
            onClick={() => onOpenStory(hadith)}
            className="w-full sm:w-4/5 py-3.5 px-6 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#E2B773]/20 active:scale-95 transition-all mb-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>الاستماع للقصة (5 مشاهد)</span>
          </button>

          <button
            onClick={() => onOpenDetail(hadith)}
            className="text-xs text-slate-400 hover:text-slate-200 mt-2 flex items-center gap-1"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>عرض التخريج الكامل والشرح</span>
          </button>
        </div>
      </div>
    </div>
  );
};
