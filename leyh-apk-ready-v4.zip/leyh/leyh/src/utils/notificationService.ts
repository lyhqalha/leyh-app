import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';

const DAILY_REMINDER_ID = 1001;
const TEST_REMINDER_ID = 1002;
const NOTIFICATION_CHANNEL_ID = 'daily-reading-v2';
const NOTIFICATION_SOUND = 'notification.wav';

const TITLE = 'تذكير القراءة اليومية - «ليه قالها؟»';
const BODY = 'حان موعد حديث اليوم وقصته النبوية 📖✨';

async function ensureChannel() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.createChannel({
      id: NOTIFICATION_CHANNEL_ID,
      name: 'تذكير القراءة اليومية',
      description: 'تنبيهات يومية لقراءة حديث اليوم وقصته',
      importance: 5,
      visibility: 1,
      sound: NOTIFICATION_SOUND,
      vibration: true,
    });
  } catch {
    // The channel may already exist or the platform may not support channels.
  }
}

async function requestNativePermission(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  try {
    const current = await LocalNotifications.checkPermissions();
    if (current.display === 'granted') return true;
    const requested = await LocalNotifications.requestPermissions();
    return requested.display === 'granted';
  } catch {
    return false;
  }
}

function nextDateForTime(time: string): Date {
  const [hours, minutes] = time.split(':').map(Number);
  const next = new Date();
  next.setSeconds(0, 0);
  next.setHours(Number.isFinite(hours) ? hours : 9, Number.isFinite(minutes) ? minutes : 0, 0, 0);
  if (next.getTime() <= Date.now()) next.setDate(next.getDate() + 1);
  return next;
}

export async function scheduleDailyReadingReminder(time: string): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureChannel();
  try {
    await LocalNotifications.cancel({ notifications: [{ id: DAILY_REMINDER_ID }] });
  } catch {
    // Nothing to cancel is fine.
  }
  try {
    await LocalNotifications.schedule({
      notifications: [{
        id: DAILY_REMINDER_ID,
        title: TITLE,
        body: BODY,
        channelId: NOTIFICATION_CHANNEL_ID,
        sound: NOTIFICATION_SOUND,
        isExactNotification: false,
        schedule: {
          at: nextDateForTime(time),
          repeats: true,
          allowWhileIdle: true,
        },
        autoCancel: true,
      }],
    });
    return true;
  } catch {
    return false;
  }
}

export async function cancelDailyReadingReminder(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await LocalNotifications.cancel({ notifications: [{ id: DAILY_REMINDER_ID }] });
  } catch {
    // Already canceled or unavailable.
  }
}

export async function sendTestReadingReminder(): Promise<boolean> {
  if (!Capacitor.isNativePlatform()) return false;
  const allowed = await requestNativePermission();
  if (!allowed) return false;
  await ensureChannel();
  try {
    await LocalNotifications.cancel({ notifications: [{ id: TEST_REMINDER_ID }] });
  } catch {
    // Nothing to cancel is fine.
  }
  try {
    await LocalNotifications.schedule({
      notifications: [{
        id: TEST_REMINDER_ID,
        title: 'إشعار تجريبي - «ليه قالها؟»',
        body: 'إذا ظهر هذا التنبيه خارج التطبيق، فالإشعارات تعمل بشكل صحيح ✅',
        channelId: NOTIFICATION_CHANNEL_ID,
        sound: NOTIFICATION_SOUND,
        isExactNotification: false,
        schedule: { at: new Date(Date.now() + 2500), allowWhileIdle: true },
        autoCancel: true,
      }],
    });
    return true;
  } catch {
    return false;
  }
}
