import { HadithItem } from '../types/hadith';

/**
 * Calculates a unique, deterministic Hadith index for any calendar date.
 * Uses a coprime multiplier (47) with 2,000 to guarantee that every single day
 * for over 5.5 years displays a completely unique Hadith with diverse topics.
 */
export function getDailyHadithIndex(date: Date = new Date(), totalHadiths: number = 2000): number {
  if (totalHadiths <= 0) return 0;
  
  // Normalize to calendar day in local time
  const year = date.getFullYear();
  const month = date.getMonth();
  const day = date.getDate();
  
  // Fixed epoch reference: Jan 1, 2024
  const epoch = new Date(2024, 0, 1).getTime();
  const current = new Date(year, month, day).getTime();
  const diffDays = Math.floor((current - epoch) / (1000 * 60 * 60 * 24));
  
  // Coprime dispersion: gcd(47, 2000) = 1
  const index = Math.abs((diffDays * 47) % totalHadiths);
  return index;
}

/**
 * Retrieves the specific Hadith assigned for the given date.
 */
export function getDailyHadith(hadiths: HadithItem[], date: Date = new Date()): HadithItem {
  if (!hadiths || hadiths.length === 0) {
    throw new Error('Hadiths database is empty');
  }
  const index = getDailyHadithIndex(date, hadiths.length);
  return hadiths[index] || hadiths[0];
}

/**
 * Formats a Date object in authentic Arabic locale.
 */
export function formatArabicDate(date: Date = new Date()): string {
  try {
    return date.toLocaleDateString('ar-EG', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  } catch {
    return date.toDateString();
  }
}

/**
 * Short formatted date (weekday and day).
 */
export function formatShortArabicDate(date: Date = new Date()): string {
  try {
    return date.toLocaleDateString('ar-EG', {
      weekday: 'short',
      day: 'numeric',
      month: 'short'
    });
  } catch {
    return date.toDateString();
  }
}
