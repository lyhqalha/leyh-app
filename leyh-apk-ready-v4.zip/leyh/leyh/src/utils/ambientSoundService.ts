/**
 * Ambient Sound Generator using Web Audio API
 * Generates delicate, serene, contextual atmospheric ambient backgrounds:
 * 1. Desert Wind & Caravan (صحراء ورياح هادئة) - soft filtered pink noise with slow warm modulation
 * 2. Reverent Sanctuary / Mosque (سكينة المسجد والمحراب) - gentle binaural warm sub-harmonics & tranquil breathing air
 * 3. Night Reflection & Stars (هدوء وسكينة الليل) - mellow resonant chimes and nocturnal silence
 * 4. River & Oasis Water (واحة وماء عذب) - delicate bubbling trickle and whispering breeze
 * 5. Campfire & Warmth (دفء المجالس وسكون) - soft warm crackle and low rumble
 * 
 * Works 100% offline, zero external audio assets required, zero CORS errors,
 * dynamically fading in/out gently behind the narrator's voice.
 */

export type AmbientContextType = 'desert' | 'sanctuary' | 'night' | 'water' | 'warmth';

export interface AmbientPreset {
  id: AmbientContextType;
  name: string;
  description: string;
  icon: string;
}

export const AMBIENT_PRESETS: Record<AmbientContextType, AmbientPreset> = {
  sanctuary: {
    id: 'sanctuary',
    name: 'سكينة المسجد والروحانية',
    description: 'ترددات هادئة توحي بروحانية المكان والخشوع والوقار',
    icon: '🕌'
  },
  desert: {
    id: 'desert',
    name: 'نسيم الصحراء والقوافل',
    description: 'همس رياح الصحراء الدافئة وسكون الرمال الواسعة',
    icon: '🏜️'
  },
  night: {
    id: 'night',
    name: 'هدوء الليل والتدبر',
    description: 'سكون الليل الهادئ للتدبر والتأمل في حكمة الحديث',
    icon: '🌙'
  },
  water: {
    id: 'water',
    name: 'خرير الواحة والماء',
    description: 'هدوء جريان الماء والواحات الرطبة ونقاء الطبيعة',
    icon: '💧'
  },
  warmth: {
    id: 'warmth',
    name: 'دفء المجالس والسكينة',
    description: 'أجواء دافئة مريحة تعزز الإنصات والتركيز في القصة',
    icon: '✨'
  }
};

/**
 * Automatically detects the most fitting ambient sound context for a given hadith
 */
export function detectAmbientContext(hadith: {
  topic?: string;
  context?: string;
  hadith_text?: string;
}): AmbientContextType {
  const combined = `${hadith.topic || ''} ${hadith.context || ''} ${hadith.hadith_text || ''}`.toLowerCase();

  // Water / Oasis / Cleansing / Sea / Rain
  if (
    combined.includes('ماء') ||
    combined.includes('وضوء') ||
    combined.includes('غسل') ||
    combined.includes('بحر') ||
    combined.includes('نهر') ||
    combined.includes('شرب') ||
    combined.includes('سقيا') ||
    combined.includes('بئر') ||
    combined.includes('مطر') ||
    combined.includes('طهارة')
  ) {
    return 'water';
  }

  // Desert / Travel / Journey / Camel / Road / Hijra
  if (
    combined.includes('سفر') ||
    combined.includes('طريق') ||
    combined.includes('صحراء') ||
    combined.includes('ناقة') ||
    combined.includes('هجرة') ||
    combined.includes('غزوة') ||
    combined.includes('رمل') ||
    combined.includes('بادية') ||
    combined.includes('أعرابي') ||
    combined.includes('خيل') ||
    combined.includes('قربة') ||
    combined.includes('شمس')
  ) {
    return 'desert';
  }

  // Night / Prayer at night / Sleep / Vigil / Reflection
  if (
    combined.includes('ليل') ||
    combined.includes('نوم') ||
    combined.includes('تهجد') ||
    combined.includes('قيام') ||
    combined.includes('فجر') ||
    combined.includes('قمر') ||
    combined.includes('نجوم') ||
    combined.includes('سحر') ||
    combined.includes('ظلام')
  ) {
    return 'night';
  }

  // Warmth / Council / Gathering / Advice / Ethics / Brothers / Charity
  if (
    combined.includes('مجلس') ||
    combined.includes('أصحاب') ||
    combined.includes('إطعام') ||
    combined.includes('طعام') ||
    combined.includes('أخلاق') ||
    combined.includes('صدقة') ||
    combined.includes('تبسم') ||
    combined.includes('محبة') ||
    combined.includes('رحمة') ||
    combined.includes('عفو') ||
    combined.includes('سلام')
  ) {
    return 'warmth';
  }

  // Sanctuary / Mosque / Prayer / Reverence default
  return 'sanctuary';
}

class AmbientSoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted: boolean = false;
  private currentType: AmbientContextType | null = null;
  private activeNodes: Array<{ stop?: () => void; disconnect: () => void }> = [];
  private volume: number = 0.22; // Very gentle background volume so it doesn't overpower speech
  private activeIntervals: number[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const savedMuted = localStorage.getItem('leh_qalha_ambient_muted');
        if (savedMuted !== null) {
          this.isMuted = savedMuted === 'true';
        }
        const savedVol = localStorage.getItem('leh_qalha_ambient_volume');
        if (savedVol !== null) {
          const v = parseFloat(savedVol);
          if (!isNaN(v) && v >= 0 && v <= 1) {
            this.volume = v;
          }
        }
      } catch {
        // Ignored
      }
    }
  }

  private initContext() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);
      }
    } else if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(vol: number) {
    this.volume = Math.max(0, Math.min(1, vol));
    try {
      localStorage.setItem('leh_qalha_ambient_volume', this.volume.toString());
    } catch {
      // Ignored
    }
    if (this.masterGain && this.ctx && !this.isMuted) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.1);
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    try {
      localStorage.setItem('leh_qalha_ambient_muted', muted ? 'true' : 'false');
    } catch {
      // Ignored
    }
    if (this.masterGain && this.ctx) {
      const target = muted ? 0 : this.volume;
      this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.15);
    }
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  public getCurrentType(): AmbientContextType | null {
    return this.currentType;
  }

  /**
   * Starts subtle ambient sound synthesis according to context
   */
  public play(type: AmbientContextType = 'sanctuary') {
    if (typeof window === 'undefined') return;
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    // If already playing the same type, smoothly ensure gain is up
    if (this.currentType === type && this.activeNodes.length > 0) {
      this.fadeIn();
      return;
    }

    this.stop(false);
    this.currentType = type;

    try {
      switch (type) {
        case 'desert':
          this.buildDesertAmbience();
          break;
        case 'water':
          this.buildWaterAmbience();
          break;
        case 'night':
          this.buildNightAmbience();
          break;
        case 'warmth':
          this.buildWarmthAmbience();
          break;
        case 'sanctuary':
        default:
          this.buildSanctuaryAmbience();
          break;
      }
      this.fadeIn();
    } catch (err) {
      console.warn('Ambient sound generation non-fatal error:', err);
    }
  }

  /**
   * Gently fades out and clears sound nodes
   */
  public stop(smooth: boolean = true) {
    this.clearAllIntervals();
    if (!this.ctx || !this.masterGain || this.activeNodes.length === 0) {
      this.currentType = null;
      return;
    }

    const fadeDuration = smooth ? 0.8 : 0.05;
    const now = this.ctx.currentTime;
    this.masterGain.gain.setTargetAtTime(0, now, fadeDuration / 3);

    const oldNodes = [...this.activeNodes];
    this.activeNodes = [];
    this.currentType = null;

    setTimeout(() => {
      oldNodes.forEach(node => {
        try {
          if (node.stop) node.stop();
          node.disconnect();
        } catch {
          // Ignored
        }
      });
      // Restore gain node target for next play
      if (this.masterGain && this.ctx && !this.isMuted) {
        this.masterGain.gain.setValueAtTime(this.volume, this.ctx.currentTime);
      }
    }, (fadeDuration + 0.1) * 1000);
  }

  private fadeIn() {
    if (!this.masterGain || !this.ctx) return;
    const target = this.isMuted ? 0 : this.volume;
    this.masterGain.gain.cancelScheduledValues(this.ctx.currentTime);
    this.masterGain.gain.setValueAtTime(0, this.ctx.currentTime);
    this.masterGain.gain.setTargetAtTime(target, this.ctx.currentTime, 0.4);
  }

  private clearAllIntervals() {
    this.activeIntervals.forEach(id => clearInterval(id));
    this.activeIntervals = [];
  }

  // --- AMBIENCE GENERATORS ---

  /**
   * 1. Sanctuary (سكينة المسجد والروحانية):
   * Pure warm acoustic drone + subtle gentle air resonance
   */
  private buildSanctuaryAmbience() {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    // Sub-harmonic warm drone (Reverent peace at ~108Hz and ~162Hz - perfect fifth, warm and peaceful)
    const osc1 = ctx.createOscillator();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(108, ctx.currentTime);

    const osc2 = ctx.createOscillator();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(162, ctx.currentTime);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(320, ctx.currentTime);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.045, ctx.currentTime);

    osc1.connect(subGain);
    osc2.connect(subGain);
    subGain.connect(filter);
    filter.connect(this.masterGain);

    osc1.start();
    osc2.start();
    this.activeNodes.push(osc1, osc2, filter, subGain);

    // Add breathing room resonance (soft filtered white noise that mimics temple/mosque air)
    this.addFilteredNoiseAir(220, 0.02, 0.15);
  }

  /**
   * 2. Desert Wind & Caravan (نسيم الصحراء والقوافل):
   * Filtered pinkish wind noise with slow, gentle swells
   */
  private buildDesertAmbience() {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    const bufferSize = ctx.sampleRate * 2;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + white * 0.0555179;
      b1 = 0.99332 * b1 + white * 0.0750759;
      b2 = 0.96900 * b2 + white * 0.1538520;
      output[i] = (b0 + b1 + b2) * 0.12;
    }

    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    // Bandpass filter for whispering wind effect
    const windFilter = ctx.createBiquadFilter();
    windFilter.type = 'bandpass';
    windFilter.frequency.setValueAtTime(450, ctx.currentTime);
    windFilter.Q.setValueAtTime(2.5, ctx.currentTime);

    const windGain = ctx.createGain();
    windGain.gain.setValueAtTime(0.06, ctx.currentTime);

    // LFO to slowly modulate wind frequency (gentle desert breeze)
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.setValueAtTime(0.2, ctx.currentTime); // 5 seconds cycle

    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(140, ctx.currentTime);

    lfo.connect(lfoGain);
    lfoGain.connect(windFilter.frequency);

    whiteNoise.connect(windFilter);
    windFilter.connect(windGain);
    windGain.connect(this.masterGain);

    whiteNoise.start();
    lfo.start();
    this.activeNodes.push(whiteNoise, lfo, windFilter, windGain, lfoGain);
  }

  /**
   * 3. Night & Reflection (هدوء الليل والتدبر):
   * Deep nocturnal low hum + delicate starry crystal chimes
   */
  private buildNightAmbience() {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    // Deep quiet night atmosphere (90 Hz sine wave)
    const nightHum = ctx.createOscillator();
    nightHum.type = 'sine';
    nightHum.frequency.setValueAtTime(90, ctx.currentTime);

    const humGain = ctx.createGain();
    humGain.gain.setValueAtTime(0.04, ctx.currentTime);

    nightHum.connect(humGain);
    humGain.connect(this.masterGain);
    nightHum.start();
    this.activeNodes.push(nightHum, humGain);

    // Gentle star chime triggered periodically (very soft, relaxing, every 6-9 seconds)
    const playSoftChime = () => {
      if (!this.ctx || !this.masterGain || this.currentType !== 'night') return;
      const chimeOsc = this.ctx.createOscillator();
      const chimeGain = this.ctx.createGain();
      const notes = [587.33, 659.25, 783.99, 880.00, 1046.50]; // D5, E5, G5, A5, C6 (Pentatonic peace)
      const note = notes[Math.floor(Math.random() * notes.length)];

      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(note, this.ctx.currentTime);

      const now = this.ctx.currentTime;
      chimeGain.gain.setValueAtTime(0, now);
      chimeGain.gain.linearRampToValueAtTime(0.012, now + 0.1);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.8);

      chimeOsc.connect(chimeGain);
      chimeGain.connect(this.masterGain);

      chimeOsc.start(now);
      chimeOsc.stop(now + 3.0);
    };

    playSoftChime();
    const intervalId = window.setInterval(playSoftChime, 7500);
    this.activeIntervals.push(intervalId);
  }

  /**
   * 4. Oasis & Pure Water (خرير الواحة والماء):
   * Subtle filtered trickle and cool soothing water presence
   */
  private buildWaterAmbience() {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    // Base tranquil stream filtered noise
    const bufferSize = ctx.sampleRate * 2;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = (Math.random() * 2 - 1) * 0.15;
    }

    const waterSource = ctx.createBufferSource();
    waterSource.buffer = noiseBuffer;
    waterSource.loop = true;

    const lowpass = ctx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(500, ctx.currentTime);

    const waterGain = ctx.createGain();
    waterGain.gain.setValueAtTime(0.035, ctx.currentTime);

    // Subtle water drop sparkle synthesizer
    const playWaterDrop = () => {
      if (!this.ctx || !this.masterGain || this.currentType !== 'water') return;
      const dropOsc = this.ctx.createOscillator();
      const dropGain = this.ctx.createGain();
      const startFreq = 700 + Math.random() * 400;

      dropOsc.type = 'sine';
      const now = this.ctx.currentTime;
      dropOsc.frequency.setValueAtTime(startFreq, now);
      dropOsc.frequency.exponentialRampToValueAtTime(startFreq + 350, now + 0.12);

      dropGain.gain.setValueAtTime(0.015, now);
      dropGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);

      dropOsc.connect(dropGain);
      dropGain.connect(this.masterGain);

      dropOsc.start(now);
      dropOsc.stop(now + 0.25);
    };

    waterSource.connect(lowpass);
    lowpass.connect(waterGain);
    waterGain.connect(this.masterGain);

    waterSource.start();
    this.activeNodes.push(waterSource, lowpass, waterGain);

    const dropInterval = window.setInterval(playWaterDrop, 3200);
    this.activeIntervals.push(dropInterval);
  }

  /**
   * 5. Warmth & Gathering (دفء المجالس والسكينة):
   * Soft warm acoustic resonance with gentle peace
   */
  private buildWarmthAmbience() {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    const warmOsc = ctx.createOscillator();
    warmOsc.type = 'sine';
    warmOsc.frequency.setValueAtTime(130.81, ctx.currentTime); // C3 warm tone

    const warmOsc2 = ctx.createOscillator();
    warmOsc2.type = 'sine';
    warmOsc2.frequency.setValueAtTime(196.00, ctx.currentTime); // G3 harmonic

    const warmGain = ctx.createGain();
    warmGain.gain.setValueAtTime(0.035, ctx.currentTime);

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(380, ctx.currentTime);

    warmOsc.connect(filter);
    warmOsc2.connect(filter);
    filter.connect(warmGain);
    warmGain.connect(this.masterGain);

    warmOsc.start();
    warmOsc2.start();
    this.activeNodes.push(warmOsc, warmOsc2, filter, warmGain);

    // Warm air presence
    this.addFilteredNoiseAir(300, 0.015, 0.2);
  }

  private addFilteredNoiseAir(freq: number, gainLevel: number, lfoSpeed: number) {
    if (!this.ctx || !this.masterGain) return;
    const ctx = this.ctx;

    const bufferSize = ctx.sampleRate;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuffer;
    noise.loop = true;

    const airFilter = ctx.createBiquadFilter();
    airFilter.type = 'bandpass';
    airFilter.frequency.setValueAtTime(freq, ctx.currentTime);
    airFilter.Q.setValueAtTime(1.5, ctx.currentTime);

    const airGain = ctx.createGain();
    airGain.gain.setValueAtTime(gainLevel, ctx.currentTime);

    noise.connect(airFilter);
    airFilter.connect(airGain);
    airGain.connect(this.masterGain);

    noise.start();
    this.activeNodes.push(noise, airFilter, airGain);
  }
}

export const ambientEngine = new AmbientSoundEngine();
