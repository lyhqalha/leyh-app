Story narration audio files go here.
Expected layout:
story-audio/<hadith-id>/scene-1.mp3 ... scene-5.mp3

These are pre-generated narrator recordings. The Android app does not ship a TTS model.
