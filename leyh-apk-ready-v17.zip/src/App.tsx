import React, { useState, useEffect } from 'react';
import { HadithItem, ActiveTab } from './types/hadith';
import { HADITHS_DATABASE } from './data/hadiths';
import { getDailyHadith } from './utils/dailyHadith';
import { HomeView } from './components/HomeView';
import { SavedView } from './components/SavedView';
import { SearchView } from './components/SearchView';
import { DailyHadithView } from './components/DailyHadithView';
import { CategoriesView } from './components/CategoriesView';
import { StoryView } from './components/StoryView';
import { HadithDetail } from './components/HadithDetail';
import { BottomNav } from './components/BottomNav';
import { ShareCardModal } from './components/ShareCardModal';
import { AudioPlayerModal } from './components/AudioPlayerModal';
import { SettingsModal } from './components/SettingsModal';
import { Bell, X, Sparkles, BookOpen } from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { scheduleDailyReadingReminder, cancelDailyReadingReminder, sendTestReadingReminder, scheduleSalawatReminder, cancelSalawatReminder, sendTestSalawatReminder } from './utils/notificationService';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [activeView, setActiveView] = useState<'tab' | 'story' | 'detail'>('tab');
  const [selectedHadith, setSelectedHadith] = useState<HadithItem>(() => getDailyHadith(HADITHS_DATABASE, new Date()));
  
  // Bookmarks persistence
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_bookmarks');
      return saved ? JSON.parse(saved) : ['hadith-6018', 'hadith-1', 'hadith-15'];
    } catch {
      return ['hadith-6018', 'hadith-1', 'hadith-15'];
    }
  });

  // Modal states
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  const language = 'ar' as const;
  const currentHadiths = HADITHS_DATABASE;

  // Appearance & Display
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_font_size');
      return saved === 'sm' || saved === 'md' || saved === 'lg' ? saved : 'md';
    } catch {
      return 'md';
    }
  });

  // Theme Modes: كحلي ليلي أو نهاري فقط
  const [themeMode, setThemeMode] = useState<'default' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_theme_mode');
      return saved === 'light' ? 'light' : 'default';
    } catch {
      return 'default';
    }
  });

  // Daily Reading Reminder (تذكير القراءة اليومي)
  const [isReminderEnabled, setIsReminderEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_enabled') === 'true';
    } catch {
      return false;
    }
  });

  const [reminderTime, setReminderTime] = useState<string>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_time') || '09:00';
    } catch {
      return '09:00';
    }
  });

  // Salawat reminder (الصلاة على النبي ﷺ)
  const [isSalawatReminderEnabled, setIsSalawatReminderEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('leh_qalha_salawat_enabled') === 'true';
    } catch {
      return false;
    }
  });

  const [salawatInterval, setSalawatInterval] = useState<30 | 60>(() => {
    try {
      return localStorage.getItem('leh_qalha_salawat_interval') === '60' ? 60 : 30;
    } catch {
      return 30;
    }
  });

  const handleToggleSalawatReminder = (enabled: boolean) => {
    setIsSalawatReminderEnabled(enabled);
    try { localStorage.setItem('leh_qalha_salawat_enabled', enabled.toString()); } catch {}
    void (enabled ? scheduleSalawatReminder(salawatInterval) : cancelSalawatReminder());
  };

  const handleChangeSalawatInterval = (interval: 30 | 60) => {
    setSalawatInterval(interval);
    try { localStorage.setItem('leh_qalha_salawat_interval', String(interval)); } catch {}
    if (isSalawatReminderEnabled) void scheduleSalawatReminder(interval);
  };

  const handleTestSalawat = () => {
    void sendTestSalawatReminder();
  };

  // In-app interactive reminder notification banner
  const [activeReminderBanner, setActiveReminderBanner] = useState<{
    title: string;
    message: string;
  } | null>(null);

  // Save Bookmarks
  useEffect(() => {
    try {
      localStorage.setItem('leh_qalha_bookmarks', JSON.stringify(bookmarkedIds));
    } catch {
      // Ignored
    }
  }, [bookmarkedIds]);

  useEffect(() => {
    document.documentElement.lang = 'ar';
    document.documentElement.dir = 'rtl';
    document.body.dir = 'rtl';
    setSelectedHadith(getDailyHadith(currentHadiths, new Date()));
  }, [currentHadiths]);

  // Sync theme preference with the DOM root. Only two modes are supported.
  useEffect(() => {
    try {
      localStorage.setItem('leh_qalha_theme_mode', themeMode);
      localStorage.removeItem('leh_qalha_ultra_dark');
      document.documentElement.classList.remove('light-mode');
      document.body.classList.remove('light-mode');
      document.documentElement.dataset.theme = themeMode;
      document.body.dataset.theme = themeMode;
      if (themeMode === 'light') {
        document.documentElement.classList.add('light-mode');
        document.body.classList.add('light-mode');
      }

      // Keep the app stable on all supported Android versions.
      // Native system-bar colors are initialized by MainActivity.
    } catch {
      // Ignored
    }
  }, [themeMode]);

  // Save Reminder settings and schedule a real Android notification when enabled
  const handleToggleReminder = (enabled: boolean) => {
    setIsReminderEnabled(enabled);
    try {
      localStorage.setItem('leh_qalha_reminder_enabled', enabled.toString());
    } catch {
      // Ignored
    }

    void (async () => {
      if (enabled) {
        const scheduled = await scheduleDailyReadingReminder(reminderTime);
        if (!scheduled && !Capacitor.isNativePlatform() && typeof window !== 'undefined' && 'Notification' in window) {
          if (Notification.permission === 'default') {
            await Notification.requestPermission();
          }
        }
      } else {
        await cancelDailyReadingReminder();
      }
    })();
  };

  const handleChangeReminderTime = (time: string) => {
    setReminderTime(time);
    try {
      localStorage.setItem('leh_qalha_reminder_time', time);
    } catch {
      // Ignored
    }
    if (isReminderEnabled) {
      void scheduleDailyReadingReminder(time);
    }
  };

  // Trigger a real device notification for testing
  const handleTestReminder = () => {
    void (async () => {
      const nativeSent = await sendTestReadingReminder();
      if (!nativeSent && typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        try {
          new Notification('إشعار تجريبي - «ليه قالها؟»', {
            body: 'إذا ظهر هذا التنبيه، فالإشعارات تعمل بشكل صحيح ✅',
            icon: '/icon.png',
          });
        } catch {
          // Ignored
        }
      }

      setActiveReminderBanner({
        title: 'اختبار تذكير القراءة',
        message: nativeSent ? 'سيظهر إشعار الجهاز خلال ثوانٍ قليلة.' : 'تم تشغيل التنبيه داخل التطبيق. إذا لم يظهر إشعار الجهاز، راجع إذن الإشعارات من إعدادات الهاتف.',
      });
    })();
  };

  // Native Android scheduling works even when the app is closed.
  useEffect(() => {
    if (!isReminderEnabled) return;
    void scheduleDailyReadingReminder(reminderTime);
  }, [isReminderEnabled, reminderTime]);

  // Re-schedule the Salawat reminders whenever the app starts or the setting changes.
  useEffect(() => {
    if (!isSalawatReminderEnabled) return;
    void scheduleSalawatReminder(salawatInterval);
  }, [isSalawatReminderEnabled, salawatInterval]);

  // Keep an in-app fallback banner for browsers/web preview.
  useEffect(() => {
    if (!isReminderEnabled || Capacitor.isNativePlatform()) return;
    const checkReminder = () => {
      const now = new Date();
      const currentTimeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
      const todayDateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      const lastRemindedDate = localStorage.getItem('leh_qalha_last_reminded_date');
      if (currentTimeStr === reminderTime && lastRemindedDate !== todayDateStr) {
        localStorage.setItem('leh_qalha_last_reminded_date', todayDateStr);
        setActiveReminderBanner({
          title: 'تذكير القراءة اليومي - حديث اليوم',
          message: 'حان موعد تدبر حديث اليوم الشريف وقراءة قصته النبوية!',
        });
      }
    };
    checkReminder();
    const interval = setInterval(checkReminder, 30000);
    return () => clearInterval(interval);
  }, [isReminderEnabled, reminderTime]);

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleOpenStory = (hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('story');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectHadithDetail = (hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToTabs = () => {
    setActiveView('tab');
  };

  const handleOpenDailyHadithFromBanner = () => {
    setActiveReminderBanner(null);
    setActiveTab('daily');
    setActiveView('tab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render the current view
  const renderCurrentView = () => {
    if (activeView === 'story') {
      return (
        <StoryView
          hadith={selectedHadith}
          onBack={handleBackToTabs}
          onOpenHadithDetail={() => setActiveView('detail')}
          fontSize={fontSize}
        />
      );
    }

    if (activeView === 'detail') {
      return (
        <HadithDetail
          hadith={selectedHadith}
          isBookmarked={bookmarkedIds.includes(selectedHadith.id)}
          onToggleBookmark={handleToggleBookmark}
          onBack={handleBackToTabs}
          onOpenStory={() => setActiveView('story')}
          onOpenShareCard={() => setIsShareModalOpen(true)}
          onOpenAudioPlayer={() => setIsAudioModalOpen(true)}
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <HomeView
            hadiths={currentHadiths}
            onOpenStory={handleOpenStory}
            onSelectHadith={handleSelectHadithDetail}
            onChangeTab={setActiveTab}
            onOpenSettings={() => setIsSettingsModalOpen(true)}
            language="ar"
          />
        );
      case 'saved':
        return (
          <SavedView
            hadiths={currentHadiths}
            bookmarkedIds={bookmarkedIds}
            onToggleBookmark={handleToggleBookmark}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'search':
        return (
          <SearchView
            hadiths={currentHadiths}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'daily':
        return (
          <DailyHadithView
            hadiths={currentHadiths}
            onOpenStory={handleOpenStory}
            onOpenDetail={handleSelectHadithDetail}
            language="ar"
          />
        );
      case 'categories':
        return (
          <CategoriesView
            hadiths={currentHadiths}
            onSelectCategoryHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 flex flex-col items-center justify-start p-0 select-none ${
        themeMode === 'light'
          ? 'bg-[#F8FAFC] text-slate-900 light-mode'
          : 'bg-[#0D131F] text-slate-100'
      }`}
    >

      {/* Main Application Container */}
      <div
        className={`w-full min-h-screen transition-all duration-300 overflow-hidden relative ${
          themeMode === 'light'
            ? 'bg-[#F8FAFC]'
            : 'bg-[#0D131F]'
        }`}
      >

        {/* In-App Daily Reminder Toast / Banner */}
        {activeReminderBanner && (
          <div className="sticky top-0 z-40 w-full p-2.5 bg-gradient-to-r from-[#172238] via-[#1F2C47] to-[#172238] border-b border-[#E2B773]/40 shadow-xl animate-fadeIn">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773] shrink-0 mt-0.5">
                  <Bell className="w-4 h-4 animate-bounce" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#E2B773] leading-tight">
                    {activeReminderBanner.title}
                  </h4>
                  <p className="text-[11px] text-slate-200 mt-0.5 leading-snug">
                    {activeReminderBanner.message}
                  </p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <button
                      onClick={handleOpenDailyHadithFromBanner}
                      className="px-3 py-1 rounded-lg bg-[#E2B773] text-[#0D131F] text-[10px] font-bold flex items-center gap-1 hover:bg-[#d4a861] active:scale-95 transition-all"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>اقرأ حديث اليوم الآن</span>
                    </button>
                    <button
                      onClick={() => setActiveReminderBanner(null)}
                      className="text-[10px] text-slate-400 hover:text-white px-2 py-1"
                    >
                      تجاهل
                    </button>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setActiveReminderBanner(null)}
                className="w-6 h-6 rounded-full bg-black/40 text-slate-400 hover:text-white flex items-center justify-center shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* View Content */}
        <div className="relative w-full">
          {renderCurrentView()}
        </div>

        {/* Bottom Tab Bar (shown when not in full-screen story mode) */}
        {activeView === 'tab' && (
          <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />
        )}
      </div>

      {/* Modals */}
      {isShareModalOpen && (
        <ShareCardModal
          hadith={selectedHadith}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}

      {isAudioModalOpen && (
        <AudioPlayerModal
          hadith={selectedHadith}
          onClose={() => setIsAudioModalOpen(false)}
        />
      )}

      {isSettingsModalOpen && (
        <SettingsModal
          onClose={() => setIsSettingsModalOpen(false)}
          fontSize={fontSize}
          onChangeFontSize={(size) => {
            setFontSize(size);
            try { localStorage.setItem('leh_qalha_font_size', size); } catch {}
          }}
          themeMode={themeMode}
          onChangeThemeMode={setThemeMode}
          isReminderEnabled={isReminderEnabled}
          onToggleReminder={handleToggleReminder}
          reminderTime={reminderTime}
          onChangeReminderTime={handleChangeReminderTime}
          onTestReminder={handleTestReminder}
          isSalawatReminderEnabled={isSalawatReminderEnabled}
          onToggleSalawatReminder={handleToggleSalawatReminder}
          salawatInterval={salawatInterval}
          onChangeSalawatInterval={handleChangeSalawatInterval}
          onTestSalawat={handleTestSalawat}
        />
      )}
    </div>
  );
}
