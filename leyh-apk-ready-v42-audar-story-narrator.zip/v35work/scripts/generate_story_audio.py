#!/usr/bin/env python3
"""Generate permanent MP3 narration for all 75 story scenes.
The Audar model is used only during GitHub Actions build time. No TTS model is
copied into the Android APK; only the resulting MP3 files are bundled.
"""
from pathlib import Path
import re, subprocess, sys, urllib.request, shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "story-audio"
DATA_FILES = [ROOT / "src" / "data" / "additionalHadiths.ts", ROOT / "src" / "data" / "moreHadiths.ts"]
AUDIO_REPO = ROOT / ".audar-tts"
REF = ROOT / ".audar-reference.wav"
REF_URL = "https://huggingface.co/audarai/Audar-TTS-V1-Flash/resolve/main/samples/demo_male_1_ar.wav"
REF_TEXT = "لا يمكنني الانتظار لأخبرك — [excited] لقد أنجزنا المشروع أخيراً بعد كلّ هذا التعب، [laughs] وصدّقني، إنه أجمل شعورٍ على الإطلاق!"


def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def scenes():
    found = []
    for path in DATA_FILES:
        text = path.read_text(encoding="utf-8")
        # Capture every hadith object and its scene audioText values.
        ids = list(re.finditer(r"\bid:\s*'([^']+)'", text))
        for i, m in enumerate(ids):
            hid = m.group(1)
            end = ids[i + 1].start() if i + 1 < len(ids) else len(text)
            body = text[m.end():end]
            for n, raw in re.findall(r"sceneNumber:\s*(\d+).*?audioText:\s*'((?:[^'\\]|\\.)*)'", body, re.S):
                audio_text = bytes(raw, "utf-8").decode("unicode_escape")
                audio_text = audio_text.replace("\r", " ").replace("\n", " ").strip()
                found.append((hid, int(n), audio_text))
    # De-duplicate in case the same id is present in both source files.
    unique = {(h, n): t for h, n, t in found}
    result = [(h, n, unique[(h, n)]) for h, n in sorted(unique)]
    if len(result) < 75:
        raise RuntimeError(f"Expected 75 story scenes, found {len(result)}")
    print(f"Found {len(result)} permanent story scenes", flush=True)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    items = scenes()

    if not AUDIO_REPO.exists():
        run(["git", "clone", "--depth", "1", "https://github.com/AudarAI/Audar-TTS-V1.git", str(AUDIO_REPO)])
    if not REF.exists():
        print("Downloading Audar's free synthetic demo_male_1 Arabic reference...", flush=True)
        urllib.request.urlretrieve(REF_URL, REF)

    # Official GGUF runtime; Flash Q4 is the lightweight tier and works on CPU.
    # Pin the CPU PyTorch stack because NeuCodec 0.0.6 requires a modern
    # PyTorch API. Do NOT let pip resolve an older CUDA torch wheel.
    run([sys.executable, "-m", "pip", "install", "--upgrade", "--index-url",
         "https://download.pytorch.org/whl/cpu",
         "torch==2.11.0", "torchaudio==2.11.0"])
    run([sys.executable, "-m", "pip", "install", "--upgrade",
         "llama-cpp-python==0.3.34", "neucodec==0.0.6", "soundfile",
         "huggingface_hub", "librosa"])

    sys.path.insert(0, str(AUDIO_REPO))
    from audar_tts import HF_REPOS, OUT_SR, build_prompt, encode_reference
    from huggingface_hub import hf_hub_download
    from llama_cpp import Llama
    from neucodec import NeuCodec
    import torch
    import soundfile as sf

    print("Loading Audar Flash Q4 once for all scenes...", flush=True)
    gguf = hf_hub_download(HF_REPOS["flash"], "Audar-TTS-V1-Flash-Q4_K_M.gguf")
    llm = Llama(model_path=gguf, n_ctx=4096, n_gpu_layers=0, verbose=False)
    codec = NeuCodec.from_pretrained("neuphonic/neucodec").eval()
    ref_codes = encode_reference(codec, str(REF))
    stop_id = llm.tokenize(b"<|TARGET_CODES_END|>", add_bos=False, special=True)[0]

    for index, (hid, n, text) in enumerate(items, 1):
        out_dir = OUT / hid
        out_dir.mkdir(parents=True, exist_ok=True)
        mp3 = out_dir / f"scene-{n}.mp3"
        if mp3.exists() and mp3.stat().st_size > 10000:
            print(f"[{index}/{len(items)}] exists: {mp3}", flush=True)
            continue

        # Storyteller delivery: restrained pauses plus occasional curiosity/excitement.
        if n == 2:
            target = f"[curious] {text}"
        elif n == 3:
            target = f"[exhales] {text}"
        elif n == 5:
            target = f"[excited] {text}"
        else:
            target = text

        prompt = build_prompt(target, REF_TEXT, ref_codes)
        toks = llm.tokenize(prompt.encode("utf-8"), add_bos=False, special=True)
        ids = []
        for tid in llm.generate(toks, temp=0.85, top_k=40, top_p=0.9, repeat_penalty=1.1):
            if tid == stop_id or len(ids) >= 2048:
                break
            ids.append(tid)
        generated = "".join(llm.detokenize([t], special=True).decode("utf-8", "ignore") for t in ids)
        codes = [int(x) for x in re.findall(r"<\|speech_(\d+)\|>", generated)]
        if not codes:
            raise RuntimeError(f"Audar generated no speech tokens for {hid} scene {n}")
        wav = codec.decode_code(torch.tensor(codes)[None, None, :]).cpu().numpy()[0, 0, :]
        wav_path = out_dir / f"scene-{n}.wav"
        sf.write(wav_path, wav, OUT_SR)
        run(["ffmpeg", "-y", "-i", str(wav_path), "-codec:a", "libmp3lame", "-b:a", "96k", str(mp3)])
        wav_path.unlink(missing_ok=True)
        print(f"[{index}/{len(items)}] generated {mp3}", flush=True)

    print("All 75 story narration MP3 files are ready.", flush=True)


if __name__ == "__main__":
    main()
